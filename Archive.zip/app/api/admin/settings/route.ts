import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { authenticateRequest } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await authenticateRequest()
    if (!user || !["ADMIN", "SUPER_ADMIN"].includes(user.role)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get system settings from database or return defaults
    const systemSettings = await prisma.systemSettings.findFirst()

    const settings = {
      general: {
        appName: systemSettings?.appName || "Kilo Super App",
        appVersion: systemSettings?.appVersion || "1.0.0",
        timezone: systemSettings?.timezone || "Africa/Lagos",
        language: systemSettings?.language || "en",
        currency: systemSettings?.currency || "NGN",
        dateFormat: systemSettings?.dateFormat || "DD/MM/YYYY",
        maintenanceMode: systemSettings?.maintenanceMode || false,
        maintenanceMessage:
          systemSettings?.maintenanceMessage || "System is under maintenance. Please try again later.",
      },
      security: {
        passwordPolicy: {
          minLength: systemSettings?.passwordMinLength || 8,
          requireUppercase: systemSettings?.passwordRequireUppercase || true,
          requireLowercase: systemSettings?.passwordRequireLowercase || true,
          requireNumbers: systemSettings?.passwordRequireNumbers || true,
          requireSpecialChars: systemSettings?.passwordRequireSpecialChars || true,
          maxAge: systemSettings?.passwordMaxAge || 90,
        },
        sessionTimeout: systemSettings?.sessionTimeout || 480,
        maxLoginAttempts: systemSettings?.maxLoginAttempts || 5,
        lockoutDuration: systemSettings?.lockoutDuration || 30,
        twoFactorRequired: systemSettings?.twoFactorRequired || false,
        ipWhitelist: systemSettings?.ipWhitelist || [],
      },
      notifications: {
        emailEnabled: systemSettings?.emailEnabled || true,
        smsEnabled: systemSettings?.smsEnabled || true,
        pushEnabled: systemSettings?.pushEnabled || true,
        emailProvider: systemSettings?.emailProvider || "sendgrid",
        smsProvider: systemSettings?.smsProvider || "twilio",
        defaultSender: systemSettings?.defaultSender || "Kilo Super App",
        templates: {
          welcome: systemSettings?.welcomeTemplate || "Welcome to Kilo Super App!",
          orderConfirmation: systemSettings?.orderConfirmationTemplate || "Your order has been confirmed.",
          passwordReset: systemSettings?.passwordResetTemplate || "Reset your password using this link.",
        },
      },
      payments: {
        defaultCurrency: systemSettings?.defaultCurrency || "NGN",
        commissionRates: {
          pharmacy: systemSettings?.pharmacyCommission || 5.0,
          autoParts: systemSettings?.autoPartsCommission || 3.0,
          food: systemSettings?.foodCommission || 15.0,
          grocery: systemSettings?.groceryCommission || 8.0,
          riding: systemSettings?.ridingCommission || 20.0,
        },
        paymentMethods: systemSettings?.paymentMethods || ["CARD", "BANK_TRANSFER", "WALLET"],
        minimumWithdrawal: systemSettings?.minimumWithdrawal || 1000,
        withdrawalFee: systemSettings?.withdrawalFee || 50,
        processingTime: systemSettings?.processingTime || "1-3 business days",
      },
      modules: {
        pharmacy: {
          enabled: systemSettings?.pharmacyEnabled || true,
          autoApproval: systemSettings?.pharmacyAutoApproval || false,
          requirePrescription: systemSettings?.pharmacyRequirePrescription || true,
          deliveryRadius: systemSettings?.pharmacyDeliveryRadius || 10,
        },
        autoParts: {
          enabled: systemSettings?.autoPartsEnabled || true,
          autoApproval: systemSettings?.autoPartsAutoApproval || false,
          warrantyRequired: systemSettings?.autoPartsWarrantyRequired || true,
          returnPeriod: systemSettings?.autoPartsReturnPeriod || 30,
        },
        food: {
          enabled: systemSettings?.foodEnabled || true,
          autoApproval: systemSettings?.foodAutoApproval || false,
          maxDeliveryTime: systemSettings?.foodMaxDeliveryTime || 60,
          qualityChecks: systemSettings?.foodQualityChecks || true,
        },
        grocery: {
          enabled: systemSettings?.groceryEnabled || true,
          autoApproval: systemSettings?.groceryAutoApproval || false,
          freshnessPeriod: systemSettings?.groceryFreshnessPeriod || 7,
          bulkOrders: systemSettings?.groceryBulkOrders || true,
        },
        riding: {
          enabled: systemSettings?.ridingEnabled || true,
          autoApproval: systemSettings?.ridingAutoApproval || false,
          backgroundCheck: systemSettings?.ridingBackgroundCheck || true,
          insuranceRequired: systemSettings?.ridingInsuranceRequired || true,
        },
      },
    }

    return NextResponse.json({ settings })
  } catch (error) {
    console.error("Error fetching system settings:", error)
    return NextResponse.json({ error: "Failed to fetch system settings" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await authenticateRequest()
    if (!user || !["ADMIN", "SUPER_ADMIN"].includes(user.role)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const settings = await request.json()

    // Update or create system settings
    const updatedSettings = await prisma.systemSettings.upsert({
      where: { id: 1 }, // Assuming single settings record
      update: {
        // General settings
        appName: settings.general.appName,
        appVersion: settings.general.appVersion,
        timezone: settings.general.timezone,
        language: settings.general.language,
        currency: settings.general.currency,
        dateFormat: settings.general.dateFormat,
        maintenanceMode: settings.general.maintenanceMode,
        maintenanceMessage: settings.general.maintenanceMessage,

        // Security settings
        passwordMinLength: settings.security.passwordPolicy.minLength,
        passwordRequireUppercase: settings.security.passwordPolicy.requireUppercase,
        passwordRequireLowercase: settings.security.passwordPolicy.requireLowercase,
        passwordRequireNumbers: settings.security.passwordPolicy.requireNumbers,
        passwordRequireSpecialChars: settings.security.passwordPolicy.requireSpecialChars,
        passwordMaxAge: settings.security.passwordPolicy.maxAge,
        sessionTimeout: settings.security.sessionTimeout,
        maxLoginAttempts: settings.security.maxLoginAttempts,
        lockoutDuration: settings.security.lockoutDuration,
        twoFactorRequired: settings.security.twoFactorRequired,
        ipWhitelist: settings.security.ipWhitelist,

        // Notification settings
        emailEnabled: settings.notifications.emailEnabled,
        smsEnabled: settings.notifications.smsEnabled,
        pushEnabled: settings.notifications.pushEnabled,
        emailProvider: settings.notifications.emailProvider,
        smsProvider: settings.notifications.smsProvider,
        defaultSender: settings.notifications.defaultSender,

        // Payment settings
        defaultCurrency: settings.payments.defaultCurrency,
        pharmacyCommission: settings.payments.commissionRates.pharmacy,
        autoPartsCommission: settings.payments.commissionRates.autoParts,
        foodCommission: settings.payments.commissionRates.food,
        groceryCommission: settings.payments.commissionRates.grocery,
        ridingCommission: settings.payments.commissionRates.riding,
        minimumWithdrawal: settings.payments.minimumWithdrawal,
        withdrawalFee: settings.payments.withdrawalFee,
        processingTime: settings.payments.processingTime,

        // Module settings
        pharmacyEnabled: settings.modules.pharmacy.enabled,
        pharmacyAutoApproval: settings.modules.pharmacy.autoApproval,
        pharmacyRequirePrescription: settings.modules.pharmacy.requirePrescription,
        pharmacyDeliveryRadius: settings.modules.pharmacy.deliveryRadius,
        autoPartsEnabled: settings.modules.autoParts.enabled,
        autoPartsAutoApproval: settings.modules.autoParts.autoApproval,
        foodEnabled: settings.modules.food.enabled,
        foodAutoApproval: settings.modules.food.autoApproval,
        groceryEnabled: settings.modules.grocery.enabled,
        groceryAutoApproval: settings.modules.grocery.autoApproval,
        ridingEnabled: settings.modules.riding.enabled,
        ridingAutoApproval: settings.modules.riding.autoApproval,
        ridingBackgroundCheck: settings.modules.riding.backgroundCheck,
        ridingInsuranceRequired: settings.modules.riding.insuranceRequired,

        updatedAt: new Date(),
      },
      create: {
        id: 1,
        // Include all the same fields as update
        appName: settings.general.appName,
        appVersion: settings.general.appVersion,
        // ... (all other fields)
      },
    })
 

    // Create audit log
    await prisma.auditLog.create({
      data: {
        performedBy: user.id,
        action: "UPDATE_SYSTEM_SETTINGS",
        entityType: "SYSTEM_SETTINGS",
        entityId: "1",
        details: {
          changes: settings,
        },
      },
    })

    return NextResponse.json({
      success: true,
      message: "System settings updated successfully",
      settings: updatedSettings,
    })
  } catch (error) {
    console.error("Error updating system settings:", error)
    return NextResponse.json({ error: "Failed to update system settings" }, { status: 500 })
  }
}
