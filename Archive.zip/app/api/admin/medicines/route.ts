import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search")
    const category = searchParams.get("category")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "20")

    const skip = (page - 1) * limit

    // Build where clause
    const where: any = {}
    if (search) {
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { genericName: { contains: search, mode: "insensitive" } },
        { manufacturer: { contains: search, mode: "insensitive" } },
      ]
    }
    if (category && category !== "ALL") {
      where.categoryId = category
    }

    const [medicines, totalCount] = await Promise.all([
      prisma.centralMedicine.findMany({
        where,
        skip,
        take: limit,
        include: {
          category: true,
        },
        orderBy: { name: "asc" },
      }),
      prisma.centralMedicine.count({ where }),
    ])

    return NextResponse.json({
      medicines,
      pagination: {
        page,
        limit,
        total: totalCount,
        pages: Math.ceil(totalCount / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching medicines:", error)
    return NextResponse.json({ error: "Failed to fetch medicines" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const medicineData = await request.json()
    const {
      name,
      genericName,
      manufacturer,
      categoryId,
      dosageForm,
      strength,
      description,
      sideEffects,
      contraindications,
      requiresPrescription,
      isControlled,
    } = medicineData

    if (!name || !categoryId) {
      return NextResponse.json({ error: "Medicine name and category are required" }, { status: 400 })
    }

    const medicine = await prisma.centralMedicine.create({
      data: {
        name,
        genericName,
        manufacturer,
        categoryId,
        dosageForm,
        strength,
        description,
        sideEffects,
        contraindications,
        requiresPrescription: requiresPrescription ?? false,
        isControlled: isControlled ?? false,
      },
      include: {
        category: true,
      },
    })

    // Log admin action
    await prisma.adminAuditLog.create({
      data: {
        adminId: session.user.id,
        action: "CREATE_CENTRAL_MEDICINE",
        module: "PHARMACY",
        details: JSON.stringify({
          medicineId: medicine.id,
          medicineName: name,
        }),
      },
    })

    return NextResponse.json({ medicine }, { status: 201 })
  } catch (error) {
    console.error("Error creating medicine:", error)
    return NextResponse.json({ error: "Failed to create medicine" }, { status: 500 })
  }
}
