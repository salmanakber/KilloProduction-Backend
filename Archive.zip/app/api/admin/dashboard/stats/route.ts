import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const range = searchParams.get("range") || "7d"

    // Calculate date range
    const now = new Date()
    let startDate: Date

    switch (range) {
      case "24h":
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000)
        break
      case "7d":
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
        break
      case "30d":
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
        break
      case "90d":
        startDate = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000)
        break
      default:
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
    }

    // Fetch comprehensive stats
    const [totalUsers, totalOrders, totalRevenue, activeComplaints, resolvedComplaints, moduleStats, recentActivities] =
      await Promise.all([
        // Total users
        prisma.user.count(),

        // Total orders in range
        prisma.order.count({
          where: {
            createdAt: { gte: startDate },
          },
        }),

        // Total revenue in range
        prisma.order.aggregate({
          where: {
            createdAt: { gte: startDate },
            status: "DELIVERED",
          },
          _sum: { totalAmount: true },
        }),

        // Active complaints
        prisma.complaint.count({
          where: {
            status: { in: ["PENDING", "IN_PROGRESS"] },
          },
        }),

        // Resolved complaints
        prisma.complaint.count({
          where: {
            status: "RESOLVED",
            updatedAt: { gte: startDate },
          },
        }),

        // Module-specific stats
        Promise.all([
          // Pharmacy stats
          Promise.all([
            prisma.user.count({ where: { role: "VENDOR", pharmacy: { isNot: null } } }),
            prisma.order.count({ where: { module: "PHARMACY", createdAt: { gte: startDate } } }),
            prisma.order.aggregate({
              where: { module: "PHARMACY", createdAt: { gte: startDate }, status: "DELIVERED" },
              _sum: { totalAmount: true },
            }),
          ]),
          // Auto Parts stats
          Promise.all([
            prisma.user.count({ where: { role: "VENDOR", autoPartsStore: { isNot: null } } }),
            prisma.order.count({ where: { module: "AUTO_PARTS", createdAt: { gte: startDate } } }),
            prisma.order.aggregate({
              where: { module: "AUTO_PARTS", createdAt: { gte: startDate }, status: "DELIVERED" },
              _sum: { totalAmount: true },
            }),
          ]),
          // Food stats
          Promise.all([
            prisma.user.count({ where: { role: "VENDOR", restaurant: { isNot: null } } }),
            prisma.order.count({ where: { module: "FOOD", createdAt: { gte: startDate } } }),
            prisma.order.aggregate({
              where: { module: "FOOD", createdAt: { gte: startDate }, status: "DELIVERED" },
              _sum: { totalAmount: true },
            }),
          ]),
          // Grocery stats
          Promise.all([
            prisma.user.count({ where: { role: "VENDOR", groceryStore: { isNot: null } } }),
            prisma.order.count({ where: { module: "GROCERY", createdAt: { gte: startDate } } }),
            prisma.order.aggregate({
              where: { module: "GROCERY", createdAt: { gte: startDate }, status: "DELIVERED" },
              _sum: { totalAmount: true },
            }),
          ]),
          // Riding stats
          Promise.all([
            prisma.user.count({ where: { role: "RIDER" } }),
            prisma.rideBooking.count({ where: { createdAt: { gte: startDate } } }),
            prisma.rideBooking.aggregate({
              where: { createdAt: { gte: startDate }, status: "COMPLETED" },
              _sum: { totalFare: true },
            }),
          ]),
        ]),

        // Recent activities
        prisma.adminAuditLog.findMany({
          take: 10,
          orderBy: { createdAt: "desc" },
          include: {
            admin: { select: { name: true } },
          },
        }),
      ])

    // Process module stats
    const [pharmacyStats, autoPartsStats, foodStats, groceryStats, ridingStats] = moduleStats

    const processedModuleStats = {
      pharmacy: {
        users: pharmacyStats[0],
        orders: pharmacyStats[1],
        revenue: pharmacyStats[2]._sum.totalAmount || 0,
      },
      autoParts: {
        users: autoPartsStats[0],
        orders: autoPartsStats[1],
        revenue: autoPartsStats[2]._sum.totalAmount || 0,
      },
      food: {
        users: foodStats[0],
        orders: foodStats[1],
        revenue: foodStats[2]._sum.totalAmount || 0,
      },
      grocery: {
        users: groceryStats[0],
        orders: groceryStats[1],
        revenue: groceryStats[2]._sum.totalAmount || 0,
      },
      riding: {
        users: ridingStats[0],
        orders: ridingStats[1],
        revenue: ridingStats[2]._sum.totalFare || 0,
      },
    }

    // Process recent activities
    const processedActivities = recentActivities.map((activity) => ({
      id: activity.id,
      type: activity.action,
      message: `${activity.action.replace("_", " ").toLowerCase()} in ${activity.module}`,
      timestamp: activity.createdAt.toISOString(),
      user: activity.admin.name,
    }))

    // Calculate monthly growth (mock calculation)
    const monthlyGrowth = 15.2

    const stats = {
      totalUsers,
      totalOrders,
      totalRevenue: totalRevenue._sum.totalAmount || 0,
      monthlyGrowth,
      activeComplaints,
      resolvedComplaints,
      moduleStats: processedModuleStats,
      recentActivities: processedActivities,
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error("Error fetching admin dashboard stats:", error)
    return NextResponse.json({ error: "Failed to fetch dashboard stats" }, { status: 500 })
  }
}
