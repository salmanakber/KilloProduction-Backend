import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { authenticateRequest } from "@/lib/auth"
import { getServerSession } from "next-auth"

export async function GET(request: NextRequest, { params }: { params: { userId: string } }) {
  try {
    const session = await authenticateRequest()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

   

    const adminUser = await prisma.user.findUnique({
      where: { id: session.id },
    })

    if (adminUser?.role !== "ADMIN" && adminUser?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }
    

    const user = await prisma.user.findUnique({
      where: { id: params.userId },
      include: {
        userProfile: true,
        autoPartsStore: true,
        pharmacy: true,
        restaurant: true,
        groceryStore: true,
        riderProfile: true,
        customerOrders: {
          take: 10,
          orderBy: { createdAt: "desc" },
          select: {
            id: true,
            total: true,
            status: true,
            createdAt: true,
            module: true,
          },
        },
        vendorOrders: {
          take: 10,
          orderBy: { createdAt: "desc" },
          select: {
            id: true,
            total: true,
            status: true,
            createdAt: true,
            module: true,
          },
        },
      },
    })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    return NextResponse.json({ user })
  } catch (error) {
    console.error("Error fetching user:", error)
    return NextResponse.json({ error: "Failed to fetch user" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { userId: string } }) {
  try {
    const session = await authenticateRequest()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const adminUser = await prisma.user.findUnique({
      where: { id: session.id },
    })

    if (adminUser?.role !== "ADMIN" && adminUser?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const body = await request.json()
    const { name, email, phone, role, isActive, isVerified } = body

    const user = await prisma.user.update({
      where: { id: params.userId },
      data: {
        name,
        email,
        phone,
        role: role?.toUpperCase(),
        isActive,
        isVerified,
      },
    })

    // Log the activity
    await prisma.auditLog.create({
      data: {
        performedBy: session.id,
        action: "UPDATE_USER",
        entityType: "User",
        entityId: user.id,
        details: { changes: body },
      },
    })

    return NextResponse.json({
      message: "User updated successfully",
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role.toLowerCase(),
        isActive: user.isActive,
        isVerified: user.isVerified,
      },
    })
  } catch (error) {
    console.error("Error updating user:", error)
    return NextResponse.json({ error: "Failed to update user" }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest, { params }: { params: { userId: string } }) {
  try {
    const session = await authenticateRequest()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const adminUser = await prisma.user.findUnique({
      where: { id: session.id },
    })

    if (adminUser?.role !== "ADMIN" && adminUser?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const { status, isVerified, isActive, ...otherUpdates } = await request.json()

    const updateData: any = {}

    if (status !== undefined) {
      // Map frontend status to backend isActive
      updateData.status = status // Directly use status enum
      updateData.isActive = status === "ACTIVE" // Keep isActive for legacy or specific checks
    }
    if (isVerified !== undefined) {
      updateData.isVerified = isVerified
    }
    if (isActive !== undefined) {
      updateData.isActive = isActive
    }

    // Add other allowed updates
    Object.assign(updateData, otherUpdates)

    const updatedUser = await prisma.user.update({
      where: { id: params.userId },
      data: updateData,
    })

    // Log admin action
    await prisma.auditLog.create({
      data: {
        performedBy: session.id,
        action: "UPDATE_USER",
        entityType: "User",
        entityId: params.userId,
        details: {
          changes: updateData,
        },
      },
    })

    // Send notification to user if status changed
    if (status && status !== updatedUser.status) {
      await prisma.notification.create({
        data: {
          userId: params.userId,
          title: `Account ${status}`,
          message: `Your account has been ${status.toLowerCase()} by admin.`,
          type: "SYSTEM",
        },
      })
    }

    return NextResponse.json({ user: updatedUser })
  } catch (error) {
    console.error("Error updating user:", error)
    return NextResponse.json({ error: "Failed to update user" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { userId: string } }) {
  try {
    const session = await authenticateRequest()
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const adminUser = await prisma.user.findUnique({
      where: { id: session.id },
    })

    if (adminUser?.role !== "ADMIN" && adminUser?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const user = await prisma.user.findUnique({
      where: { id: params.userId },
    })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Soft delete by deactivating the user
    await prisma.user.update({
      where: { id: params.userId },
      data: {
        isActive: false,
        deletedAt: new Date(),
      },
    })

    // Log the activity
    await prisma.auditLog.create({
      data: {
        performedBy: session.id,
        action: "DELETE_USER",
        entityType: "User",
        entityId: params.userId,
        details: {
          changes: user,
        },
      },
    })

    return NextResponse.json({
      message: "User deleted successfully",
    })
  } catch (error) {
    console.error("Error deleting user:", error)
    return NextResponse.json({ error: "Failed to delete user" }, { status: 500 })
  }
}
