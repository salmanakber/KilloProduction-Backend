import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const status = searchParams.get("status")
    const search = searchParams.get("search")

    const skip = (page - 1) * limit

    // Build where clause
    const where: any = {
      restaurant: {
        isNot: null,
      },
    }

    if (status && status !== "ALL") {
      where.restaurant = {
        ...where.restaurant,
        isVerified: status === "APPROVED",
      }
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { email: { contains: search, mode: "insensitive" } },
        { phone: { contains: search, mode: "insensitive" } },
        { restaurant: { name: { contains: search, mode: "insensitive" } } },
      ]
    }

    const [restaurants, totalCount] = await Promise.all([
      prisma.user.findMany({
        where,
        skip,
        take: limit,
        include: {
          restaurant: {
            include: {
              _count: {
                select: {
                  menuItems: true,
                },
              },
            },
          },
          vendorOrders: {
            where: {
              module: "FOOD",
            },
            select: {
              id: true,
              total: true,
              status: true,
            },
          },
        },
        orderBy: { createdAt: "desc" },
      }),
      prisma.user.count({ where }),
    ])

    const formattedRestaurants = restaurants.map((restaurant) => {
      const totalRevenue = restaurant.vendorOrders?.reduce((sum, order) => sum + order.total, 0) || 0
      const totalOrders = restaurant.vendorOrders?.length || 0

      return {
        id: restaurant.id,
        name: restaurant.restaurant?.name || restaurant.name || "Unknown",
        email: restaurant.email || "",
        phone: restaurant.phone || "",
        address: restaurant.restaurant?.address || "",
        cuisine: restaurant.restaurant?.cuisine || [],
        status: restaurant.restaurant?.isVerified ? "APPROVED" : "PENDING",
        isOpen: restaurant.restaurant?.isOpen || false,
        rating: restaurant.restaurant?.rating || 0,
        totalOrders,
        revenue: totalRevenue,
        joinedAt: restaurant.createdAt.toISOString(),
        logo: restaurant.restaurant?.logo,
        coverImage: restaurant.restaurant?.coverImage,
        deliveryTime: restaurant.restaurant?.deliveryTime || "30-45 mins",
        deliveryFee: restaurant.restaurant?.deliveryFee || 0,
        minOrderAmount: restaurant.restaurant?.minOrderAmount || 0,
        documents: {
          businessLicense: "/placeholder-document.jpg",
          foodSafetyCert: "/placeholder-document.jpg",
          ownerPhoto: "/placeholder-profile.jpg",
        },
      }
    })

    return NextResponse.json({
      restaurants: formattedRestaurants,
      pagination: {
        page,
        limit,
        total: totalCount,
        pages: Math.ceil(totalCount / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching restaurants:", error)
    return NextResponse.json({ error: "Failed to fetch restaurants" }, { status: 500 })
  }
}
