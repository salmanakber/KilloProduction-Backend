import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const { status } = await request.json()
    const riderId = params.id

    // Update rider profile status
    const updatedProfile = await prisma.riderProfile.update({
      where: { userId: riderId },
      data: {
        isApproved: status === "APPROVED",
        isVerified: status !== "REJECTED",
        approvedAt: status === "APPROVED" ? new Date() : null,
        approvedBy: status === "APPROVED" ? session.user.id : null,
        verificationNotes: status === "REJECTED" ? "Rejected by admin" : null,
      },
    })

    // Create audit log
    await prisma.auditLog.create({
      data: {
        action: "UPDATE_RIDER_STATUS",
        entityType: "RIDER",
        entityId: riderId,
        details: {
          newStatus: status,
          previousStatus: updatedProfile.isApproved ? "APPROVED" : "PENDING",
        },
        performedBy: session.user.id,
      },
    })

    // Send notification to rider
    await prisma.notification.create({
      data: {
        userId: riderId,
        title: `Application ${status}`,
        message:
          status === "APPROVED"
            ? "Congratulations! Your rider application has been approved. You can now start accepting rides."
            : status === "REJECTED"
              ? "Your rider application has been rejected. Please contact support for more information."
              : "Your rider application is under review.",
        type: "SYSTEM",
      },
    })

    return NextResponse.json({
      success: true,
      message: `Rider ${status.toLowerCase()} successfully`,
    })
  } catch (error) {
    console.error("Error updating rider status:", error)
    return NextResponse.json({ error: "Failed to update rider status" }, { status: 500 })
  }
}
