import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const status = searchParams.get("status")
    const search = searchParams.get("search")

    const skip = (page - 1) * limit

    // Build where clause
    const where: any = {
      role: "RIDER",
      riderProfile: {
        isNot: null,
      },
    }

    if (status && status !== "ALL") {
      where.riderProfile = {
        ...where.riderProfile,
        isApproved: status === "APPROVED",
      }
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { email: { contains: search, mode: "insensitive" } },
        { phone: { contains: search, mode: "insensitive" } },
      ]
    }

    const [riders, totalCount] = await Promise.all([
      prisma.user.findMany({
        where,
        skip,
        take: limit,
        include: {
          riderProfile: true,
          riderEarnings: {
            select: {
              amount: true,
            },
          },
          customerRideBookings: {
            select: {
              id: true,
              status: true,
            },
          },
        },
        orderBy: { createdAt: "desc" },
      }),
      prisma.user.count({ where }),
    ])

    const formattedRiders = riders.map((rider) => ({
      id: rider.id,
      name: rider.name || "Unknown",
      email: rider.email || "",
      phone: rider.phone || "",
      vehicleType: rider.riderProfile?.vehicleType || "Unknown",
      vehiclePlate: rider.riderProfile?.licensePlate || "Unknown",
      status: rider.riderProfile?.isApproved ? "APPROVED" : rider.riderProfile?.isVerified ? "PENDING" : "REJECTED",
      isOnline: rider.riderProfile?.isOnline || false,
      rating: rider.riderProfile?.rating || 0,
      totalRides: rider.customerRideBookings?.length || 0,
      totalEarnings: rider.riderEarnings?.reduce((sum, earning) => sum + earning.amount, 0) || 0,
      joinedAt: rider.createdAt.toISOString(),
      documents: {
        license: rider.riderProfile?.licensePhoto || "/placeholder-document.jpg",
        insurance: rider.riderProfile?.insurancePhoto || "/placeholder-document.jpg",
        vehicleRegistration: rider.riderProfile?.vehiclePhotos?.[0] || "/placeholder-document.jpg",
        profilePhoto: rider.riderProfile?.selfiePhoto || "/placeholder-profile.jpg",
      },
      location: rider.riderProfile?.currentLocation
        ? {
            lat: (rider.riderProfile.currentLocation as any).lat,
            lng: (rider.riderProfile.currentLocation as any).lng,
            address: "Current Location", // You'd need to reverse geocode this
          }
        : undefined,
    }))

    return NextResponse.json({
      riders: formattedRiders,
      pagination: {
        page,
        limit,
        total: totalCount,
        pages: Math.ceil(totalCount / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching riders:", error)
    return NextResponse.json({ error: "Failed to fetch riders" }, { status: 500 })
  }
}
