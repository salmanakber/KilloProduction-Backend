import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const [totalPharmacies, pendingApprovals, activePharmacies, suspendedPharmacies, ordersData, reviewsData] =
      await Promise.all([
        prisma.pharmacy.count(),
        prisma.pharmacy.count({ where: { status: "PENDING" } }),
        prisma.pharmacy.count({ where: { status: "APPROVED" } }),
        prisma.pharmacy.count({ where: { status: "SUSPENDED" } }),
        prisma.order.aggregate({
          where: { module: "PHARMACY" },
          _sum: { totalAmount: true },
          _count: true,
        }),
        prisma.review.aggregate({
          where: {
            order: { module: "PHARMACY" },
          },
          _avg: { rating: true },
        }),
      ])

    const stats = {
      totalPharmacies,
      pendingApprovals,
      activePharmacies,
      suspendedPharmacies,
      totalRevenue: ordersData._sum.totalAmount || 0,
      totalOrders: ordersData._count || 0,
      averageRating: reviewsData._avg.rating || 0,
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error("Error fetching pharmacy stats:", error)
    return NextResponse.json({ error: "Failed to fetch pharmacy stats" }, { status: 500 })
  }
}
