import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const search = searchParams.get("search") || ""
    const status = searchParams.get("status") || "ALL"
    const limit = 20

    const where: any = {}

    if (search) {
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { ownerName: { contains: search, mode: "insensitive" } },
        { licenseNumber: { contains: search, mode: "insensitive" } },
      ]
    }

    if (status !== "ALL") {
      where.status = status
    }

    const pharmacies = await prisma.pharmacy.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
            isVerified: true,
            createdAt: true,
          },
        },
        orders: {
          select: {
            id: true,
            totalAmount: true,
          },
        },
        reviews: {
          select: {
            rating: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * limit,
      take: limit,
    })

    const formattedPharmacies = pharmacies.map((pharmacy) => ({
      id: pharmacy.id,
      name: pharmacy.name,
      ownerName: pharmacy.ownerName,
      email: pharmacy.user?.email || pharmacy.email,
      phone: pharmacy.user?.phone || pharmacy.phone,
      address: pharmacy.address,
      licenseNumber: pharmacy.licenseNumber,
      status: pharmacy.status,
      isVerified: pharmacy.user?.isVerified || false,
      registrationDate: pharmacy.createdAt.toISOString(),
      totalOrders: pharmacy.orders.length,
      totalRevenue: pharmacy.orders.reduce((sum, order) => sum + order.totalAmount, 0),
      rating:
        pharmacy.reviews.length > 0
          ? pharmacy.reviews.reduce((sum, review) => sum + review.rating, 0) / pharmacy.reviews.length
          : 0,
      specializations: pharmacy.specializations || [],
      medicineOrigins: pharmacy.medicineOrigins || [],
      documents: {
        businessLicense: pharmacy.businessLicense || "",
        pharmacyLicense: pharmacy.pharmacyLicense || "",
        ownerPhoto: pharmacy.ownerPhoto || "",
      },
    }))

    return NextResponse.json({ pharmacies: formattedPharmacies })
  } catch (error) {
    console.error("Error fetching pharmacies:", error)
    return NextResponse.json({ error: "Failed to fetch pharmacies" }, { status: 500 })
  }
}
