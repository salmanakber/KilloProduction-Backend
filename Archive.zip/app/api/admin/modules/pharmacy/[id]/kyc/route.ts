import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const { action, reason } = await request.json()

    if (!["approve", "reject"].includes(action)) {
      return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }

    const pharmacy = await prisma.pharmacy.findUnique({
      where: { id: params.id },
      include: { user: true },
    })

    if (!pharmacy) {
      return NextResponse.json({ error: "Pharmacy not found" }, { status: 404 })
    }

    const newStatus = action === "approve" ? "APPROVED" : "REJECTED"

    // Update pharmacy status
    await prisma.pharmacy.update({
      where: { id: params.id },
      data: {
        status: newStatus,
        approvedAt: action === "approve" ? new Date() : null,
        rejectedAt: action === "reject" ? new Date() : null,
        rejectionReason: action === "reject" ? reason : null,
      },
    })

    // Create audit log
    await prisma.adminAuditLog.create({
      data: {
        adminId: session.user.id,
        action: `${action.toUpperCase()}_PHARMACY`,
        module: "PHARMACY_MANAGEMENT",
        targetId: params.id,
        details: {
          pharmacyName: pharmacy.name,
          action,
          reason,
        },
      },
    })

    // Send notification to pharmacy owner
    if (pharmacy.user) {
      await prisma.notification.create({
        data: {
          userId: pharmacy.user.id,
          title: `Pharmacy ${action === "approve" ? "Approved" : "Rejected"}`,
          message:
            action === "approve"
              ? "Congratulations! Your pharmacy has been approved and is now active."
              : `Your pharmacy application has been rejected. Reason: ${reason}`,
          type: "SYSTEM",
          module: "PHARMACY",
        },
      })
    }

    return NextResponse.json({
      success: true,
      message: `Pharmacy ${action}d successfully`,
    })
  } catch (error) {
    console.error("Error updating pharmacy KYC:", error)
    return NextResponse.json({ error: "Failed to update pharmacy status" }, { status: 500 })
  }
}
