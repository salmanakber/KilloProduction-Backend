import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const status = searchParams.get("status")
    const search = searchParams.get("search")

    const skip = (page - 1) * limit

    // Build where clause
    const where: any = {
      groceryStore: {
        isNot: null,
      },
    }

    if (status && status !== "ALL") {
      where.groceryStore = {
        ...where.groceryStore,
        isVerified: status === "APPROVED",
      }
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: "insensitive" } },
        { email: { contains: search, mode: "insensitive" } },
        { phone: { contains: search, mode: "insensitive" } },
        { groceryStore: { storeName: { contains: search, mode: "insensitive" } } },
      ]
    }

    const [stores, totalCount] = await Promise.all([
      prisma.user.findMany({
        where,
        skip,
        take: limit,
        include: {
          groceryStore: {
            include: {
              _count: {
                select: {
                  products: true,
                },
              },
            },
          },
          vendorOrders: {
            where: {
              module: "GROCERY",
            },
            select: {
              id: true,
              total: true,
              status: true,
            },
          },
        },
        orderBy: { createdAt: "desc" },
      }),
      prisma.user.count({ where }),
    ])

    const formattedStores = stores.map((store) => {
      const totalRevenue = store.vendorOrders?.reduce((sum, order) => sum + order.total, 0) || 0
      const totalOrders = store.vendorOrders?.length || 0

      return {
        id: store.id,
        name: store.groceryStore?.storeName || store.name || "Unknown",
        email: store.email || "",
        phone: store.phone || "",
        address: store.groceryStore?.address || "",
        storeType: store.groceryStore?.storeType || [],
        status: store.groceryStore?.isVerified ? "APPROVED" : "PENDING",
        isOpen: store.groceryStore?.isOpen || false,
        rating: store.groceryStore?.rating || 0,
        totalOrders,
        revenue: totalRevenue,
        totalProducts: store.groceryStore?._count?.products || 0,
        joinedAt: store.createdAt.toISOString(),
        logo: store.groceryStore?.logo,
        coverImage: store.groceryStore?.coverImage,
        deliveryFee: store.groceryStore?.deliveryFee || 0,
        minOrderAmount: store.groceryStore?.minOrderAmount || 0,
        maxDeliveryDistance: store.groceryStore?.maxDeliveryDistance || 0,
        documents: {
          businessLicense: "/placeholder-document.jpg",
          healthPermit: "/placeholder-document.jpg",
          ownerPhoto: "/placeholder-profile.jpg",
        },
      }
    })

    return NextResponse.json({
      stores: formattedStores,
      pagination: {
        page,
        limit,
        total: totalCount,
        pages: Math.ceil(totalCount / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching grocery stores:", error)
    return NextResponse.json({ error: "Failed to fetch grocery stores" }, { status: 500 })
  }
}
