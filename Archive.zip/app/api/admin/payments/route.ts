import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const type = searchParams.get("type")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const startDate = searchParams.get("startDate")
    const endDate = searchParams.get("endDate")

    const skip = (page - 1) * limit

    // Build where clause
    const where: any = {}
    if (status && status !== "ALL") {
      where.status = status
    }
    if (type && type !== "ALL") {
      where.type = type
    }
    if (startDate && endDate) {
      where.createdAt = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      }
    }

    // Get payments from wallet transactions
    const [payments, totalCount] = await Promise.all([
      prisma.walletTransaction.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: "desc" },
        include: {
          wallet: {
            include: {
              user: {
                select: {
                  id: true,
                  name: true,
                  email: true,
                  role: true,
                },
              },
            },
          },
          order: {
            select: {
              id: true,
              orderNumber: true,
              vendor: {
                select: {
                  name: true,
                },
              },
            },
          },
        },
      }),
      prisma.walletTransaction.count({ where }),
    ])

    // Format payments for frontend
    const formattedPayments = payments.map((payment) => ({
      id: payment.id,
      transactionId: payment.transactionId,
      amount: payment.amount,
      currency: payment.currency || "USD",
      status: payment.status,
      type: payment.type,
      method: payment.paymentMethod || "UNKNOWN",
      userId: payment.wallet.user.id,
      userName: payment.wallet.user.name,
      userType: payment.wallet.user.role,
      vendorId: payment.order?.vendor?.name ? payment.order.id : null,
      vendorName: payment.order?.vendor?.name || null,
      orderId: payment.order?.id || null,
      orderNumber: payment.order?.orderNumber || null,
      description: payment.description,
      createdAt: payment.createdAt,
      processedAt: payment.updatedAt,
      fees: {
        platformFee: payment.platformFee || 0,
        processingFee: payment.processingFee || 0,
        total: (payment.platformFee || 0) + (payment.processingFee || 0),
      },
      failureReason: payment.failureReason,
    }))

    return NextResponse.json({
      payments: formattedPayments,
      pagination: {
        page,
        limit,
        total: totalCount,
        pages: Math.ceil(totalCount / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching payments:", error)
    return NextResponse.json({ error: "Failed to fetch payments" }, { status: 500 })
  }
}
