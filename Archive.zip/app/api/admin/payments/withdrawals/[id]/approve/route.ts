import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const withdrawalId = params.id

    // In a real implementation, you would:
    // 1. Update the withdrawal status in the database
    // 2. Initiate the bank transfer
    // 3. Create audit log entry
    // 4. Send notification to vendor

    // Mock response
    const updatedWithdrawal = {
      id: withdrawalId,
      status: "APPROVED",
      processedAt: new Date().toISOString(),
      processedBy: user.name || "Admin User",
    }

    return NextResponse.json({
      success: true,
      message: "Withdrawal approved successfully",
      withdrawal: updatedWithdrawal,
    })
  } catch (error) {
    console.error("Error approving withdrawal:", error)
    return NextResponse.json({ error: "Failed to approve withdrawal" }, { status: 500 })
  }
}
