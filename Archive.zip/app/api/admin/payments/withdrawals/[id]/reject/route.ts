import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const withdrawalId = params.id
    const { reason } = await request.json()

    // In a real implementation, you would:
    // 1. Update the withdrawal status in the database
    // 2. Store the rejection reason
    // 3. Create audit log entry
    // 4. Send notification to vendor with reason

    const updatedWithdrawal = {
      id: withdrawalId,
      status: "REJECTED",
      processedAt: new Date().toISOString(),
      processedBy: user.name || "Admin User",
      rejectionReason: reason || "No reason provided",
    }

    return NextResponse.json({
      success: true,
      message: "Withdrawal rejected successfully",
      withdrawal: updatedWithdrawal,
    })
  } catch (error) {
    console.error("Error rejecting withdrawal:", error)
    return NextResponse.json({ error: "Failed to reject withdrawal" }, { status: 500 })
  }
}
