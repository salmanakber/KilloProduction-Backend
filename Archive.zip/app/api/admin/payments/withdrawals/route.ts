import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "20")

    const skip = (page - 1) * limit

    // Build where clause
    const where: any = {}
    if (status && status !== "ALL") {
      where.status = status
    }

    // Get withdrawal requests from database
    const [withdrawals, totalCount] = await Promise.all([
      prisma.vendorWithdrawal.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: "desc" },
        include: {
          vendor: {
            select: {
              id: true,
              name: true,
              email: true,
              phone: true,
            },
          },
          bankAccount: {
            select: {
              accountName: true,
              accountNumber: true,
              bankName: true,
              routingNumber: true,
            },
          },
          processedBy: {
            select: {
              name: true,
            },
          },
        },
      }),
      prisma.vendorWithdrawal.count({ where }),
    ])

    // Format withdrawals for frontend
    const formattedWithdrawals = withdrawals.map((withdrawal) => ({
      id: withdrawal.id,
      vendorId: withdrawal.vendor.id,
      vendorName: withdrawal.vendor.name,
      vendorEmail: withdrawal.vendor.email,
      vendorPhone: withdrawal.vendor.phone,
      amount: withdrawal.amount,
      currency: withdrawal.currency,
      bankDetails: withdrawal.bankAccount
        ? {
            accountName: withdrawal.bankAccount.accountName,
            accountNumber: withdrawal.bankAccount.accountNumber,
            bankName: withdrawal.bankAccount.bankName,
            routingNumber: withdrawal.bankAccount.routingNumber,
          }
        : null,
      status: withdrawal.status,
      requestedAt: withdrawal.createdAt,
      processedAt: withdrawal.processedAt,
      processedBy: withdrawal.processedBy?.name,
      rejectionReason: withdrawal.rejectionReason,
      notes: withdrawal.notes,
    }))

    return NextResponse.json({
      withdrawals: formattedWithdrawals,
      pagination: {
        page,
        limit,
        total: totalCount,
        pages: Math.ceil(totalCount / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching withdrawals:", error)
    return NextResponse.json({ error: "Failed to fetch withdrawals" }, { status: 500 })
  }
}
