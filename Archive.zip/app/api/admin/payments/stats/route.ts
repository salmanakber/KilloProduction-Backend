import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const range = searchParams.get("range") || "30d"

    // Calculate date range
    const endDate = new Date()
    const startDate = new Date()

    switch (range) {
      case "24h":
        startDate.setDate(startDate.getDate() - 1)
        break
      case "7d":
        startDate.setDate(startDate.getDate() - 7)
        break
      case "30d":
        startDate.setDate(startDate.getDate() - 30)
        break
      case "90d":
        startDate.setDate(startDate.getDate() - 90)
        break
      default:
        startDate.setDate(startDate.getDate() - 30)
    }

    // Get payment statistics
    const [
      totalVolumeResult,
      totalTransactions,
      successfulTransactions,
      pendingPayments,
      failedPayments,
      totalRefunds,
      pendingWithdrawals,
      totalCommission,
    ] = await Promise.all([
      prisma.walletTransaction.aggregate({
        where: {
          status: "COMPLETED",
          createdAt: { gte: startDate, lte: endDate },
        },
        _sum: { amount: true },
      }),
      prisma.walletTransaction.count({
        where: {
          createdAt: { gte: startDate, lte: endDate },
        },
      }),
      prisma.walletTransaction.count({
        where: {
          status: "COMPLETED",
          createdAt: { gte: startDate, lte: endDate },
        },
      }),
      prisma.walletTransaction.count({
        where: {
          status: "PENDING",
          createdAt: { gte: startDate, lte: endDate },
        },
      }),
      prisma.walletTransaction.count({
        where: {
          status: "FAILED",
          createdAt: { gte: startDate, lte: endDate },
        },
      }),
      prisma.walletTransaction.aggregate({
        where: {
          type: "REFUND",
          createdAt: { gte: startDate, lte: endDate },
        },
        _sum: { amount: true },
      }),
      prisma.vendorWithdrawal.count({
        where: { status: "PENDING" },
      }),
      prisma.vendorCommission.aggregate({
        where: {
          status: "PAID",
          createdAt: { gte: startDate, lte: endDate },
        },
        _sum: { commissionAmount: true },
      }),
    ])

    const successRate = totalTransactions > 0 ? (successfulTransactions / totalTransactions) * 100 : 0

    const stats = {
      totalVolume: totalVolumeResult._sum.amount || 0,
      totalTransactions,
      successRate: Math.round(successRate * 100) / 100,
      pendingPayments,
      failedPayments,
      totalRefunds: totalRefunds._sum.amount || 0,
      pendingWithdrawals,
      totalCommission: totalCommission._sum.commissionAmount || 0,
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error("Error fetching payment stats:", error)
    return NextResponse.json({ error: "Failed to fetch payment stats" }, { status: 500 })
  }
}
