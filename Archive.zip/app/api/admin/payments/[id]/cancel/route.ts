import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
    })

    if (user?.role !== "ADMIN" && user?.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const paymentId = params.id
    const { reason } = await request.json()

    // In a real implementation, you would:
    // 1. Validate the payment exists and can be cancelled
    // 2. Cancel the payment through the payment gateway
    // 3. Update the payment status in the database
    // 4. Create audit log entry
    // 5. Send notification to customer

    const cancelResult = {
      paymentId,
      status: "CANCELLED",
      reason: reason || "Admin cancelled payment",
      cancelledBy: user.name || "Admin User",
      cancelledAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      message: "Payment cancelled successfully",
      result: cancelResult,
    })
  } catch (error) {
    console.error("Error cancelling payment:", error)
    return NextResponse.json({ error: "Failed to cancel payment" }, { status: 500 })
  }
}
