import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { sendOTP, generateOTP } from "@/lib/twilio"
import bcrypt from "bcryptjs"

export async function POST(request: NextRequest) {
  try {
    const { phone, email, password } = await request.json()

    // Find user by phone or email
    const user = await prisma.user.findFirst({
      where: {
        OR: [{ phone }, { email: email || undefined } ],
      },
      include: {
        userProfile: true,
        userSettings: true,
        wallet: true,
        autoPartsStore: true,
        pharmacy: true,
        restaurant: true,
        groceryStore: true,
        riderProfile: true,
      },
    })
    if (!user.isActive) {
      return NextResponse.json({ error: "Account is deactivated" }, { status: 403 })
    }
    if (user.password && !bcrypt.compareSync(password, user.password)) {
      return NextResponse.json({ error: "Invalid password" }, { status: 401 })
    }

    // Generate OTP
    const otpCode = generateOTP()

    // Send OTP to user's phone
    await sendOTP(user.phone!, otpCode)

    // Store OTP in DB (valid for 5 minutes)
    await prisma.otp.create({
      data: {
        userId: user.id,
        phone: user.phone!,
        code: otpCode,
        expiresAt: new Date(Date.now() + Number(process.env.OTP_EXPIRY_MINUTES || 5) * 60 * 1000), // 5 min expiry
        verified: false,
      },
    })

    return NextResponse.json({
      message: "OTP sent to your phone",
      userId: user.id,
      requiresVerification: true,
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Login failed" }, { status: 500 })
  }
}
