"use client"

import { useState } from "react"
import { DollarSign, TrendingUp, Edit, Save, X, Plus, BarChart3, Calendar } from "lucide-react"

interface CommissionSetting {
  id: string
  module: "PHARMACY" | "AUTO_PARTS" | "FOOD" | "GROCERY" | "RIDING"
  type: "PERCENTAGE" | "FIXED" | "TIERED"
  value: number
  minValue?: number
  maxValue?: number
  tiers?: {
    min: number
    max: number
    rate: number
  }[]
  isActive: boolean
  createdAt: string
  updatedAt: string
}

interface CommissionStats {
  totalCommission: number
  pendingCommission: number
  paidCommission: number
  monthlyGrowth: number
  topEarners: {
    vendorId: string
    vendorName: string
    commission: number
    orders: number
  }[]
}

export default function CommissionManagement() {
  const [commissionSettings, setCommissionSettings] = useState<CommissionSetting[]>([
    {
      id: "1",
      module: "PHARMACY",
      type: "PERCENTAGE",
      value: 5.0,
      isActive: true,
      createdAt: "2024-01-01T00:00:00Z",
      updatedAt: "2024-01-01T00:00:00Z",
    },
    {
      id: "2",
      module: "AUTO_PARTS",
      type: "PERCENTAGE",
      value: 3.5,
      isActive: true,
      createdAt: "2024-01-01T00:00:00Z",
      updatedAt: "2024-01-01T00:00:00Z",
    },
    {
      id: "3",
      module: "FOOD",
      type: "TIERED",
      value: 0,
      tiers: [
        { min: 0, max: 1000, rate: 8.0 },
        { min: 1001, max: 5000, rate: 6.0 },
        { min: 5001, max: 999999, rate: 4.0 },
      ],
      isActive: true,
      createdAt: "2024-01-01T00:00:00Z",
      updatedAt: "2024-01-01T00:00:00Z",
    },
    {
      id: "4",
      module: "GROCERY",
      type: "PERCENTAGE",
      value: 4.0,
      isActive: true,
      createdAt: "2024-01-01T00:00:00Z",
      updatedAt: "2024-01-01T00:00:00Z",
    },
    {
      id: "5",
      module: "RIDING",
      type: "FIXED",
      value: 2.0,
      isActive: true,
      createdAt: "2024-01-01T00:00:00Z",
      updatedAt: "2024-01-01T00:00:00Z",
    },
  ])

  const [stats, setStats] = useState<CommissionStats>({
    totalCommission: 45678.9,
    pendingCommission: 12345.67,
    paidCommission: 33333.23,
    monthlyGrowth: 12.5,
    topEarners: [
      { vendorId: "1", vendorName: "MediCare Pharmacy", commission: 2345.67, orders: 156 },
      { vendorId: "2", vendorName: "AutoParts Plus", commission: 1876.54, orders: 89 },
      { vendorId: "3", vendorName: "Fresh Grocery", commission: 1654.32, orders: 234 },
      { vendorId: "4", vendorName: "Pizza Palace", commission: 1432.1, orders: 67 },
      { vendorId: "5", vendorName: "Quick Ride", commission: 987.65, orders: 445 },
    ],
  })

  const [editingId, setEditingId] = useState<string | null>(null)
  const [editForm, setEditForm] = useState<Partial<CommissionSetting>>({})

  const handleEdit = (setting: CommissionSetting) => {
    setEditingId(setting.id)
    setEditForm(setting)
  }

  const handleSave = () => {
    if (editingId && editForm) {
      setCommissionSettings((prev) =>
        prev.map((setting) =>
          setting.id === editingId ? { ...setting, ...editForm, updatedAt: new Date().toISOString() } : setting,
        ),
      )
      setEditingId(null)
      setEditForm({})
    }
  }

  const handleCancel = () => {
    setEditingId(null)
    setEditForm({})
  }

  const getModuleColor = (module: string) => {
    switch (module) {
      case "PHARMACY":
        return "text-green-800 bg-green-100"
      case "AUTO_PARTS":
        return "text-blue-800 bg-blue-100"
      case "FOOD":
        return "text-yellow-800 bg-yellow-100"
      case "GROCERY":
        return "text-purple-800 bg-purple-100"
      case "RIDING":
        return "text-red-800 bg-red-100"
      default:
        return "text-gray-800 bg-gray-100"
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "PERCENTAGE":
        return "text-blue-800 bg-blue-100"
      case "FIXED":
        return "text-green-800 bg-green-100"
      case "TIERED":
        return "text-purple-800 bg-purple-100"
      default:
        return "text-gray-800 bg-gray-100"
    }
  }

  const formatCommissionValue = (setting: CommissionSetting) => {
    if (setting.type === "PERCENTAGE") {
      return `${setting.value}%`
    } else if (setting.type === "FIXED") {
      return `$${setting.value}`
    } else if (setting.type === "TIERED" && setting.tiers) {
      return `${setting.tiers.length} tiers`
    }
    return "N/A"
  }

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Commission Management</h1>
              <p className="mt-2 text-gray-600">Manage commission rates and track earnings across all modules</p>
            </div>
            <button className="bg-[#2E8B57] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-[#228B22] flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span>Add Commission Rule</span>
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center">
              <div className="h-12 w-12 bg-[#2E8B57] bg-opacity-10 rounded-lg flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-[#2E8B57]" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Total Commission</p>
                <p className="text-2xl font-bold text-gray-900">${stats.totalCommission.toLocaleString()}</p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center">
              <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Calendar className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Pending</p>
                <p className="text-2xl font-bold text-gray-900">${stats.pendingCommission.toLocaleString()}</p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center">
              <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Paid Out</p>
                <p className="text-2xl font-bold text-gray-900">${stats.paidCommission.toLocaleString()}</p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <div className="flex items-center">
              <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <BarChart3 className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Monthly Growth</p>
                <div className="flex items-center">
                  <p className="text-2xl font-bold text-gray-900">{stats.monthlyGrowth}%</p>
                  <TrendingUp className="h-4 w-4 text-green-500 ml-2" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Commission Settings */}
          <div className="lg:col-span-2">
            <div className="bg-white shadow-sm rounded-lg border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900">Commission Settings</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Module
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Type
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Rate
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {commissionSettings.map((setting) => (
                      <tr key={setting.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getModuleColor(setting.module)}`}
                          >
                            {setting.module.replace("_", " ")}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getTypeColor(setting.type)}`}
                          >
                            {setting.type}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {editingId === setting.id ? (
                            <div className="flex items-center space-x-2">
                              {setting.type === "PERCENTAGE" && (
                                <div className="flex items-center">
                                  <input
                                    type="number"
                                    step="0.1"
                                    className="w-20 px-2 py-1 border border-gray-300 rounded text-sm"
                                    value={editForm.value || 0}
                                    onChange={(e) =>
                                      setEditForm({ ...editForm, value: Number.parseFloat(e.target.value) })
                                    }
                                  />
                                  <span className="ml-1 text-sm text-gray-500">%</span>
                                </div>
                              )}
                              {setting.type === "FIXED" && (
                                <div className="flex items-center">
                                  <span className="text-sm text-gray-500">$</span>
                                  <input
                                    type="number"
                                    step="0.01"
                                    className="w-20 px-2 py-1 border border-gray-300 rounded text-sm ml-1"
                                    value={editForm.value || 0}
                                    onChange={(e) =>
                                      setEditForm({ ...editForm, value: Number.parseFloat(e.target.value) })
                                    }
                                  />
                                </div>
                              )}
                              {setting.type === "TIERED" && (
                                <button className="text-[#2E8B57] text-sm hover:text-[#228B22]">Edit Tiers</button>
                              )}
                            </div>
                          ) : (
                            <div className="text-sm font-medium text-gray-900">{formatCommissionValue(setting)}</div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                              setting.isActive ? "text-green-800 bg-green-100" : "text-red-800 bg-red-100"
                            }`}
                          >
                            {setting.isActive ? "Active" : "Inactive"}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          {editingId === setting.id ? (
                            <div className="flex items-center space-x-2">
                              <button onClick={handleSave} className="text-green-600 hover:text-green-500">
                                <Save className="h-4 w-4" />
                              </button>
                              <button onClick={handleCancel} className="text-red-600 hover:text-red-500">
                                <X className="h-4 w-4" />
                              </button>
                            </div>
                          ) : (
                            <button onClick={() => handleEdit(setting)} className="text-[#2E8B57] hover:text-[#228B22]">
                              <Edit className="h-4 w-4" />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Top Earners */}
          <div>
            <div className="bg-white shadow-sm rounded-lg border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900">Top Commission Earners</h3>
              </div>
              <div className="p-6 space-y-4">
                {stats.topEarners.map((earner, index) => (
                  <div key={earner.vendorId} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="h-8 w-8 bg-[#2E8B57] rounded-full flex items-center justify-center">
                        <span className="text-white font-medium text-sm">{index + 1}</span>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">{earner.vendorName}</p>
                        <p className="text-xs text-gray-500">{earner.orders} orders</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-[#2E8B57]">${earner.commission.toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
