"use client"

import { useState, useEffect } from "react"
import {
  CreditCard,
  DollarSign,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertTriangle,
  Download,
  Search,
  Filter,
  Eye,
  RefreshCw,
  Ban,
  User,
  Building,
} from "lucide-react"

interface Payment {
  id: string
  transactionId: string
  amount: number
  currency: string
  status: "PENDING" | "COMPLETED" | "FAILED" | "REFUNDED" | "DISPUTED"
  type: "ORDER_PAYMENT" | "VENDOR_PAYOUT" | "REFUND" | "COMMISSION"
  method: "CARD" | "BANK_TRANSFER" | "WALLET" | "MOBILE_MONEY"
  userId: string
  userName: string
  userType: "CUSTOMER" | "VENDOR" | "RIDER"
  vendorId?: string
  vendorName?: string
  orderId?: string
  description: string
  createdAt: string
  processedAt?: string
  failureReason?: string
  fees: {
    platformFee: number
    processingFee: number
    total: number
  }
}

interface WithdrawalRequest {
  id: string
  vendorId: string
  vendorName: string
  amount: number
  bankDetails: {
    accountName: string
    accountNumber: string
    bankName: string
    routingNumber?: string
  }
  status: "PENDING" | "APPROVED" | "PROCESSING" | "COMPLETED" | "REJECTED"
  requestedAt: string
  processedAt?: string
  processedBy?: string
  rejectionReason?: string
}

interface PaymentStats {
  totalVolume: number
  totalTransactions: number
  successRate: number
  pendingPayments: number
  failedPayments: number
  totalRefunds: number
  pendingWithdrawals: number
  totalCommission: number
}

export default function PaymentManagement() {
  const [payments, setPayments] = useState<Payment[]>([])
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([])
  const [stats, setStats] = useState<PaymentStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("payments")
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState("ALL")
  const [selectedType, setSelectedType] = useState("ALL")
  const [dateRange, setDateRange] = useState("7d")

  useEffect(() => {
    fetchPaymentData()
  }, [dateRange, selectedStatus, selectedType])

  const fetchPaymentData = async () => {
    try {
      const [paymentsResponse, withdrawalsResponse, statsResponse] = await Promise.all([
        fetch(`/api/admin/payments?range=${dateRange}&status=${selectedStatus}&type=${selectedType}`),
        fetch(`/api/admin/payments/withdrawals?range=${dateRange}`),
        fetch(`/api/admin/payments/stats?range=${dateRange}`),
      ])

      const [paymentsData, withdrawalsData, statsData] = await Promise.all([
        paymentsResponse.json(),
        withdrawalsResponse.json(),
        statsResponse.json(),
      ])

      setPayments(paymentsData.payments)
      setWithdrawals(withdrawalsData.withdrawals)
      setStats(statsData)
    } catch (error) {
      console.error("Failed to fetch payment data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handlePaymentAction = async (paymentId: string, action: "refund" | "retry" | "cancel") => {
    try {
      const response = await fetch(`/api/admin/payments/${paymentId}/${action}`, {
        method: "POST",
      })
      if (response.ok) {
        fetchPaymentData()
      }
    } catch (error) {
      console.error(`Failed to ${action} payment:`, error)
    }
  }

  const handleWithdrawalAction = async (withdrawalId: string, action: "approve" | "reject", reason?: string) => {
    try {
      const response = await fetch(`/api/admin/payments/withdrawals/${withdrawalId}/${action}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason }),
      })
      if (response.ok) {
        fetchPaymentData()
      }
    } catch (error) {
      console.error(`Failed to ${action} withdrawal:`, error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "COMPLETED":
        return "bg-green-100 text-green-800"
      case "PENDING":
        return "bg-yellow-100 text-yellow-800"
      case "FAILED":
        return "bg-red-100 text-red-800"
      case "REFUNDED":
        return "bg-blue-100 text-blue-800"
      case "DISPUTED":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case "CARD":
        return <CreditCard className="h-4 w-4" />
      case "BANK_TRANSFER":
        return <Building className="h-4 w-4" />
      case "WALLET":
        return <DollarSign className="h-4 w-4" />
      case "MOBILE_MONEY":
        return <CreditCard className="h-4 w-4" />
      default:
        return <CreditCard className="h-4 w-4" />
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Payment Management</h1>
          <p className="text-gray-600 mt-1">Monitor transactions, process withdrawals, and manage payment flows</p>
        </div>
        <div className="flex items-center space-x-3">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
          >
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
          <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Volume</p>
              <p className="text-3xl font-bold text-gray-900">${stats?.totalVolume?.toLocaleString()}</p>
            </div>
            <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
              <DollarSign className="h-6 w-6 text-green-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-600 font-medium">+12.5%</span>
            <span className="text-sm text-gray-500 ml-1">vs last period</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Transactions</p>
              <p className="text-3xl font-bold text-gray-900">{stats?.totalTransactions?.toLocaleString()}</p>
            </div>
            <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <CreditCard className="h-6 w-6 text-blue-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
            <span className="text-sm text-green-600 font-medium">{stats?.successRate}% success rate</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Pending</p>
              <p className="text-3xl font-bold text-gray-900">{stats?.pendingPayments}</p>
            </div>
            <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Clock className="h-6 w-6 text-yellow-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <AlertTriangle className="h-4 w-4 text-red-500 mr-1" />
            <span className="text-sm text-red-600 font-medium">{stats?.failedPayments} failed</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Commission</p>
              <p className="text-3xl font-bold text-gray-900">${stats?.totalCommission?.toLocaleString()}</p>
            </div>
            <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="h-6 w-6 text-purple-600" />
            </div>
          </div>
          <div className="mt-4 flex items-center">
            <span className="text-sm text-gray-600">{stats?.pendingWithdrawals} pending withdrawals</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab("payments")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "payments"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Payments
            </button>
            <button
              onClick={() => setActiveTab("withdrawals")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "withdrawals"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Withdrawals
            </button>
            <button
              onClick={() => setActiveTab("disputes")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "disputes"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Disputes
            </button>
            <button
              onClick={() => setActiveTab("analytics")}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === "analytics"
                  ? "border-green-500 text-green-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              Analytics
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "payments" && (
            <div className="space-y-6">
              {/* Filters */}
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                <div className="flex-1 max-w-lg">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <input
                      type="text"
                      placeholder="Search by transaction ID, user, or order..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value)}
                    className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                  >
                    <option value="ALL">All Status</option>
                    <option value="PENDING">Pending</option>
                    <option value="COMPLETED">Completed</option>
                    <option value="FAILED">Failed</option>
                    <option value="REFUNDED">Refunded</option>
                    <option value="DISPUTED">Disputed</option>
                  </select>
                  <select
                    value={selectedType}
                    onChange={(e) => setSelectedType(e.target.value)}
                    className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                  >
                    <option value="ALL">All Types</option>
                    <option value="ORDER_PAYMENT">Order Payment</option>
                    <option value="VENDOR_PAYOUT">Vendor Payout</option>
                    <option value="REFUND">Refund</option>
                    <option value="COMMISSION">Commission</option>
                  </select>
                  <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <Filter className="h-4 w-4 mr-2" />
                    More Filters
                  </button>
                </div>
              </div>

              {/* Payments Table */}
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Transaction
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        User
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Amount
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Method
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {payments?.map((payment) => (
                      <tr key={payment.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div>
                            <div className="text-sm font-medium text-gray-900">{payment.transactionId}</div>
                            <div className="text-sm text-gray-500">{payment.type.replace("_", " ")}</div>
                            {payment.orderId && <div className="text-xs text-gray-400">Order: {payment.orderId}</div>}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center">
                            <div className="h-8 w-8 bg-gray-200 rounded-full flex items-center justify-center">
                              <User className="h-4 w-4 text-gray-500" />
                            </div>
                            <div className="ml-3">
                              <div className="text-sm font-medium text-gray-900">{payment.userName}</div>
                              <div className="text-sm text-gray-500">{payment.userType}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              ${payment.amount.toFixed(2)} {payment.currency}
                            </div>
                            <div className="text-xs text-gray-500">Fee: ${payment.fees.total.toFixed(2)}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center">
                            {getPaymentMethodIcon(payment.method)}
                            <span className="ml-2 text-sm text-gray-900">{payment.method.replace("_", " ")}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span
                            className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(payment.status)}`}
                          >
                            {payment.status}
                          </span>
                          {payment.failureReason && (
                            <div className="text-xs text-red-600 mt-1">{payment.failureReason}</div>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900">
                            {new Date(payment.createdAt).toLocaleDateString()}
                          </div>
                          <div className="text-xs text-gray-500">
                            {new Date(payment.createdAt).toLocaleTimeString()}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-2">
                            <button className="text-green-600 hover:text-green-900">
                              <Eye className="h-4 w-4" />
                            </button>
                            {payment.status === "FAILED" && (
                              <button
                                onClick={() => handlePaymentAction(payment.id, "retry")}
                                className="text-blue-600 hover:text-blue-900"
                              >
                                <RefreshCw className="h-4 w-4" />
                              </button>
                            )}
                            {payment.status === "COMPLETED" && (
                              <button
                                onClick={() => handlePaymentAction(payment.id, "refund")}
                                className="text-orange-600 hover:text-orange-900"
                              >
                                <RefreshCw className="h-4 w-4" />
                              </button>
                            )}
                            {payment.status === "PENDING" && (
                              <button
                                onClick={() => handlePaymentAction(payment.id, "cancel")}
                                className="text-red-600 hover:text-red-900"
                              >
                                <Ban className="h-4 w-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === "withdrawals" && (
            <div className="space-y-4">
              {withdrawals?.map((withdrawal) => (
                <div key={withdrawal.id} className="bg-gray-50 p-6 rounded-lg border">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <h4 className="text-lg font-medium text-gray-900">{withdrawal.vendorName}</h4>
                        <span
                          className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(withdrawal.status)}`}
                        >
                          {withdrawal.status}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div>
                          <p className="text-sm font-medium text-gray-600">Amount</p>
                          <p className="text-lg font-semibold text-gray-900">${withdrawal.amount.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-600">Bank Account</p>
                          <p className="text-sm text-gray-900">{withdrawal.bankDetails.accountName}</p>
                          <p className="text-sm text-gray-500">
                            {withdrawal.bankDetails.bankName} - ****{withdrawal.bankDetails.accountNumber.slice(-4)}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-600">Requested</p>
                          <p className="text-sm text-gray-900">
                            {new Date(withdrawal.requestedAt).toLocaleDateString()}
                          </p>
                          <p className="text-sm text-gray-500">
                            {new Date(withdrawal.requestedAt).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>

                      {withdrawal.rejectionReason && (
                        <div className="bg-red-50 border border-red-200 p-3 rounded mb-4">
                          <p className="text-sm text-red-800">
                            <strong>Rejection Reason:</strong> {withdrawal.rejectionReason}
                          </p>
                        </div>
                      )}
                    </div>

                    {withdrawal.status === "PENDING" && (
                      <div className="flex items-center space-x-2 ml-4">
                        <button
                          onClick={() => handleWithdrawalAction(withdrawal.id, "approve")}
                          className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => handleWithdrawalAction(withdrawal.id, "reject", "Insufficient documentation")}
                          className="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700"
                        >
                          Reject
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "disputes" && (
            <div className="text-center py-12">
              <AlertTriangle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Payment Disputes</h3>
              <p className="text-gray-600 mb-4">Manage and resolve payment disputes and chargebacks</p>
              <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                View All Disputes
              </button>
            </div>
          )}

          {activeTab === "analytics" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Payment Methods Distribution</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <CreditCard className="h-4 w-4 text-blue-600 mr-2" />
                        <span className="text-sm text-gray-700">Credit/Debit Cards</span>
                      </div>
                      <span className="text-sm font-medium text-gray-900">65%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Building className="h-4 w-4 text-green-600 mr-2" />
                        <span className="text-sm text-gray-700">Bank Transfer</span>
                      </div>
                      <span className="text-sm font-medium text-gray-900">20%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <DollarSign className="h-4 w-4 text-purple-600 mr-2" />
                        <span className="text-sm text-gray-700">Digital Wallet</span>
                      </div>
                      <span className="text-sm font-medium text-gray-900">15%</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Transaction Trends</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">Peak Hours</span>
                      <span className="text-sm font-medium text-gray-900">6-8 PM</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">Average Transaction</span>
                      <span className="text-sm font-medium text-gray-900">$45.67</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">Processing Time</span>
                      <span className="text-sm font-medium text-gray-900">2.3 seconds</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-700">Failure Rate</span>
                      <span className="text-sm font-medium text-red-600">2.1%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
