"use client"

import type React from "react"
import { useState } from "react"
import { SessionProvider } from "next-auth/react"
import { usePathname } from "next/navigation"
import AdminSidebar from "@/components/admin/AdminSidebar"
import AdminHeader from "@/components/admin/AdminHeader"
import "../globals.css"

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const pathname = usePathname()

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
  }

  // Check if current route is login page
  const isLoginPage = pathname === "/admin/login" || pathname === "/admin/forgot-password" // adjust path as needed

  return (
    <SessionProvider>
      <div className="min-h-screen bg-gray-50">
        <div className="flex h-screen">
          {!isLoginPage && (
            <div
              className={`${
                isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
              } fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-200 transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0`}
            >
              <AdminSidebar />
            </div>
          )}

          {/* Mobile overlay */}
          {!isLoginPage && isMobileMenuOpen && (
            <div
              className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
              onClick={() => setIsMobileMenuOpen(false)}
            />
          )}

          {/* Main content */}
          <div className="flex-1 flex flex-col overflow-hidden">
            {!isLoginPage && (
              <AdminHeader onMenuToggle={toggleMobileMenu} isMobileMenuOpen={isMobileMenuOpen} />
            )}
            <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-6">
              {children}
            </main>
          </div>
        </div>
      </div>
    </SessionProvider>
  )
}
