"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle, XCircle, Clock, Users, TrendingUp, AlertTriangle, Eye, UserCheck, UserX } from "lucide-react"

interface RiderStats {
  totalRiders: number
  activeRiders: number
  pendingApproval: number
  totalEarnings: number
  averageRating: number
  completionRate: number
}

interface Rider {
  id: string
  name: string
  email: string
  phone: string
  vehicleType: string
  status: "PENDING" | "APPROVED" | "REJECTED" | "SUSPENDED"
  rating: number
  totalRides: number
  totalEarnings: number
  documentsVerified: boolean
  createdAt: string
  lastActive: string
}

export default function RiderManagementPage() {
  const [stats, setStats] = useState<RiderStats | null>(null)
  const [riders, setRiders] = useState<Rider[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("ALL")
  const [selectedRider, setSelectedRider] = useState<Rider | null>(null)

  useEffect(() => {
    fetchRiderStats()
    fetchRiders()
  }, [])

  const fetchRiderStats = async () => {
    try {
      const response = await fetch("/api/admin/modules/rider/stats")
      const data = await response.json()
      setStats(data)
    } catch (error) {
      console.error("Error fetching rider stats:", error)
    }
  }

  const fetchRiders = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/admin/modules/rider/list")
      const data = await response.json()
      setRiders(data.riders || [])
    } catch (error) {
      console.error("Error fetching riders:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleStatusChange = async (riderId: string, newStatus: string) => {
    try {
      const response = await fetch(`/api/admin/modules/rider/${riderId}/kyc`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status: newStatus }),
      })

      if (response.ok) {
        fetchRiders()
        fetchRiderStats()
      }
    } catch (error) {
      console.error("Error updating rider status:", error)
    }
  }

  const filteredRiders = riders.filter((rider) => {
    const matchesSearch =
      rider.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rider.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rider.phone.includes(searchTerm)
    const matchesStatus = statusFilter === "ALL" || rider.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    const variants = {
      PENDING: "secondary",
      APPROVED: "default",
      REJECTED: "destructive",
      SUSPENDED: "outline",
    }
    return <Badge variant={variants[status as keyof typeof variants]}>{status}</Badge>
  }

  if (loading && !stats) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Rider Management</h1>
          <p className="text-muted-foreground">Manage riders, approvals, and performance</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Riders</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalRiders || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Riders</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.activeRiders || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approval</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.pendingApproval || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.averageRating?.toFixed(1) || "0.0"}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Riders</CardTitle>
          <CardDescription>Manage and monitor all riders</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-4">
            <Input
              placeholder="Search riders..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Status</SelectItem>
                <SelectItem value="PENDING">Pending</SelectItem>
                <SelectItem value="APPROVED">Approved</SelectItem>
                <SelectItem value="REJECTED">Rejected</SelectItem>
                <SelectItem value="SUSPENDED">Suspended</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Riders Table */}
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Rider</TableHead>
                <TableHead>Vehicle</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Rating</TableHead>
                <TableHead>Total Rides</TableHead>
                <TableHead>Earnings</TableHead>
                <TableHead>Documents</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRiders.map((rider) => (
                <TableRow key={rider.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{rider.name}</div>
                      <div className="text-sm text-muted-foreground">{rider.email}</div>
                      <div className="text-sm text-muted-foreground">{rider.phone}</div>
                    </div>
                  </TableCell>
                  <TableCell>{rider.vehicleType}</TableCell>
                  <TableCell>{getStatusBadge(rider.status)}</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <span className="mr-1">⭐</span>
                      {rider.rating.toFixed(1)}
                    </div>
                  </TableCell>
                  <TableCell>{rider.totalRides}</TableCell>
                  <TableCell>₦{rider.totalEarnings.toLocaleString()}</TableCell>
                  <TableCell>
                    {rider.documentsVerified ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-yellow-600" />
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" onClick={() => setSelectedRider(rider)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>Rider Details</DialogTitle>
                            <DialogDescription>View and manage rider information</DialogDescription>
                          </DialogHeader>
                          {selectedRider && (
                            <RiderDetailsModal rider={selectedRider} onStatusChange={handleStatusChange} />
                          )}
                        </DialogContent>
                      </Dialog>

                      {rider.status === "PENDING" && (
                        <>
                          <Button variant="outline" size="sm" onClick={() => handleStatusChange(rider.id, "APPROVED")}>
                            <UserCheck className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm" onClick={() => handleStatusChange(rider.id, "REJECTED")}>
                            <UserX className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

function RiderDetailsModal({
  rider,
  onStatusChange,
}: { rider: Rider; onStatusChange: (id: string, status: string) => void }) {
  return (
    <Tabs defaultValue="profile" className="w-full">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="profile">Profile</TabsTrigger>
        <TabsTrigger value="documents">Documents</TabsTrigger>
        <TabsTrigger value="performance">Performance</TabsTrigger>
      </TabsList>

      <TabsContent value="profile" className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium">Name</label>
            <p className="text-sm text-muted-foreground">{rider.name}</p>
          </div>
          <div>
            <label className="text-sm font-medium">Email</label>
            <p className="text-sm text-muted-foreground">{rider.email}</p>
          </div>
          <div>
            <label className="text-sm font-medium">Phone</label>
            <p className="text-sm text-muted-foreground">{rider.phone}</p>
          </div>
          <div>
            <label className="text-sm font-medium">Vehicle Type</label>
            <p className="text-sm text-muted-foreground">{rider.vehicleType}</p>
          </div>
          <div>
            <label className="text-sm font-medium">Status</label>
            <div className="mt-1">{getStatusBadge(rider.status)}</div>
          </div>
          <div>
            <label className="text-sm font-medium">Joined</label>
            <p className="text-sm text-muted-foreground">{new Date(rider.createdAt).toLocaleDateString()}</p>
          </div>
        </div>

        <div className="flex gap-2 pt-4">
          <Button onClick={() => onStatusChange(rider.id, "APPROVED")} disabled={rider.status === "APPROVED"}>
            Approve
          </Button>
          <Button
            variant="outline"
            onClick={() => onStatusChange(rider.id, "REJECTED")}
            disabled={rider.status === "REJECTED"}
          >
            Reject
          </Button>
          <Button
            variant="destructive"
            onClick={() => onStatusChange(rider.id, "SUSPENDED")}
            disabled={rider.status === "SUSPENDED"}
          >
            Suspend
          </Button>
        </div>
      </TabsContent>

      <TabsContent value="documents" className="space-y-4">
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <h4 className="font-medium">Driver's License</h4>
              <p className="text-sm text-muted-foreground">Required for verification</p>
            </div>
            {rider.documentsVerified ? (
              <CheckCircle className="h-5 w-5 text-green-600" />
            ) : (
              <XCircle className="h-5 w-5 text-red-600" />
            )}
          </div>
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <h4 className="font-medium">Vehicle Registration</h4>
              <p className="text-sm text-muted-foreground">Vehicle ownership proof</p>
            </div>
            {rider.documentsVerified ? (
              <CheckCircle className="h-5 w-5 text-green-600" />
            ) : (
              <XCircle className="h-5 w-5 text-red-600" />
            )}
          </div>
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <h4 className="font-medium">Insurance</h4>
              <p className="text-sm text-muted-foreground">Valid insurance coverage</p>
            </div>
            {rider.documentsVerified ? (
              <CheckCircle className="h-5 w-5 text-green-600" />
            ) : (
              <XCircle className="h-5 w-5 text-red-600" />
            )}
          </div>
        </div>
      </TabsContent>

      <TabsContent value="performance" className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Total Rides</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{rider.totalRides}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Rating</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{rider.rating.toFixed(1)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Total Earnings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₦{rider.totalEarnings.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Last Active</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm">{new Date(rider.lastActive).toLocaleDateString()}</div>
            </CardContent>
          </Card>
        </div>
      </TabsContent>
    </Tabs>
  )
}

function getStatusBadge(status: string) {
  const variants = {
    PENDING: "secondary",
    APPROVED: "default",
    REJECTED: "destructive",
    SUSPENDED: "outline",
  }
  return <Badge variant={variants[status as keyof typeof variants] as any}>{status}</Badge>
}
