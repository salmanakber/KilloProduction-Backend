"use client"

import { useState, useEffect } from "react"
import {
  Store,
  TrendingUp,
  CheckCircle,
  XCircle,
  Eye,
  Edit,
  MoreHorizontal,
  Download,
  Filter,
  Search,
  DollarSign,
  Clock,
} from "lucide-react"

interface PharmacyData {
  id: string
  name: string
  ownerName: string
  email: string
  phone: string
  address: string
  licenseNumber: string
  status: "PENDING" | "APPROVED" | "REJECTED" | "SUSPENDED"
  isVerified: boolean
  registrationDate: string
  totalOrders: number
  totalRevenue: number
  rating: number
  specializations: string[]
  medicineOrigins: string[]
  documents: {
    businessLicense: string
    pharmacyLicense: string
    ownerPhoto: string
  }
}

interface PharmacyStats {
  totalPharmacies: number
  pendingApprovals: number
  activePharmacies: number
  suspendedPharmacies: number
  totalRevenue: number
  totalOrders: number
  averageRating: number
}

export default function PharmacyManagement() {
  const [pharmacies, setPharmacies] = useState<PharmacyData[]>([])
  const [stats, setStats] = useState<PharmacyStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedPharmacy, setSelectedPharmacy] = useState<PharmacyData | null>(null)
  const [showKYCModal, setShowKYCModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("ALL")
  const [currentPage, setCurrentPage] = useState(1)

  useEffect(() => {
    fetchPharmacyData()
  }, [currentPage, searchTerm, statusFilter])

  const fetchPharmacyData = async () => {
    try {
      const [pharmaciesResponse, statsResponse] = await Promise.all([
        fetch(`/api/admin/modules/pharmacy/list?page=${currentPage}&search=${searchTerm}&status=${statusFilter}`),
        fetch("/api/admin/modules/pharmacy/stats"),
      ])

      const [pharmaciesData, statsData] = await Promise.all([pharmaciesResponse.json(), statsResponse.json()])

      setPharmacies(pharmaciesData.pharmacies)
      setStats(statsData)
    } catch (error) {
      console.error("Failed to fetch pharmacy data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleKYCAction = async (pharmacyId: string, action: "approve" | "reject", reason?: string) => {
    try {
      const response = await fetch(`/api/admin/modules/pharmacy/${pharmacyId}/kyc`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, reason }),
      })

      if (response.ok) {
        fetchPharmacyData()
        setShowKYCModal(false)
        setSelectedPharmacy(null)
      }
    } catch (error) {
      console.error("Failed to update KYC status:", error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "APPROVED":
        return "bg-green-100 text-green-800"
      case "PENDING":
        return "bg-yellow-100 text-yellow-800"
      case "REJECTED":
        return "bg-red-100 text-red-800"
      case "SUSPENDED":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Pharmacy Management</h1>
          <p className="text-gray-600 mt-1">Manage pharmacy registrations, KYC approvals, and performance</p>
        </div>
        <div className="flex items-center space-x-3">
          <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download className="h-4 w-4 mr-2" />
            Export Data
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Pharmacies</p>
              <p className="text-3xl font-bold text-gray-900">{stats?.totalPharmacies}</p>
            </div>
            <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Store className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Pending Approvals</p>
              <p className="text-3xl font-bold text-gray-900">{stats?.pendingApprovals}</p>
            </div>
            <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Clock className="h-6 w-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Revenue</p>
              <p className="text-3xl font-bold text-gray-900">₦{stats?.totalRevenue?.toLocaleString()}</p>
            </div>
            <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
              <DollarSign className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Average Rating</p>
              <p className="text-3xl font-bold text-gray-900">{stats?.averageRating?.toFixed(1)}</p>
            </div>
            <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div className="flex-1 max-w-lg">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search pharmacies by name, owner, or license..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
            >
              <option value="ALL">All Status</option>
              <option value="PENDING">Pending</option>
              <option value="APPROVED">Approved</option>
              <option value="REJECTED">Rejected</option>
              <option value="SUSPENDED">Suspended</option>
            </select>
            <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
              <Filter className="h-4 w-4 mr-2" />
              More Filters
            </button>
          </div>
        </div>
      </div>

      {/* Pharmacies Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pharmacy Details
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Owner & Contact
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status & Verification
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Performance
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {pharmacies?.map((pharmacy) => (
                <tr key={pharmacy.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{pharmacy.name}</div>
                      <div className="text-sm text-gray-500">License: {pharmacy.licenseNumber}</div>
                      <div className="text-sm text-gray-500">{pharmacy.address}</div>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {pharmacy.specializations?.slice(0, 2).map((spec) => (
                          <span key={spec} className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded">
                            {spec}
                          </span>
                        ))}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{pharmacy?.ownerName}</div>
                      <div className="text-sm text-gray-500">{pharmacy?.email}</div>
                      <div className="text-sm text-gray-500">{pharmacy?.phone}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="space-y-1">
                      <span
                        className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(pharmacy?.status)}`}
                      >
                        {pharmacy?.status}
                      </span>
                      <div className="flex items-center text-xs text-gray-500">
                        {pharmacy?.isVerified ? (
                          <CheckCircle className="h-3 w-3 text-green-500 mr-1" />
                        ) : (
                          <XCircle className="h-3 w-3 text-red-500 mr-1" />
                        )}
                        {pharmacy?.isVerified ? "Verified" : "Unverified"}
                      </div>
                      <div className="text-xs text-gray-500">
                        Registered: {new Date(pharmacy?.registrationDate).toLocaleDateString()}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm">
                      <div className="text-gray-900">{pharmacy?.totalOrders} orders</div>
                      <div className="text-gray-500">₦{pharmacy?.totalRevenue?.toLocaleString()}</div>
                      <div className="flex items-center mt-1">
                        <span className="text-xs text-gray-600">★ {pharmacy?.rating?.toFixed(1)}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => {
                          setSelectedPharmacy(pharmacy)
                          setShowKYCModal(true)
                        }}
                        className="text-green-600 hover:text-green-900"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button className="text-blue-600 hover:text-blue-900">
                        <Edit className="h-4 w-4" />
                      </button>
                      <button className="text-gray-400 hover:text-gray-600">
                        <MoreHorizontal className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* KYC Review Modal */}
      {showKYCModal && selectedPharmacy && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">KYC Review - {selectedPharmacy.name}</h2>
              <button onClick={() => setShowKYCModal(false)} className="text-gray-400 hover:text-gray-600">
                <XCircle className="h-6 w-6" />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Pharmacy Information</h3>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Pharmacy Name</label>
                    <p className="text-gray-900">{selectedPharmacy?.name}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Owner Name</label>
                    <p className="text-gray-900">{selectedPharmacy?.ownerName}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">License Number</label>
                    <p className="text-gray-900">{selectedPharmacy?.licenseNumber}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Address</label>
                    <p className="text-gray-900">{selectedPharmacy?.address}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Specializations</label>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {selectedPharmacy?.specializations?.map((spec) => (
                        <span key={spec} className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded">
                          {spec}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Medicine Origins</label>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {selectedPharmacy?.medicineOrigins?.map((origin) => (
                        <span key={origin} className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded">
                          {origin}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">Documents</h3>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-600">Business License</label>
                    <div className="mt-1 border border-gray-300 rounded-lg p-4">
                      <img
                        src={selectedPharmacy?.documents?.businessLicense || "/placeholder.svg"}
                        alt="Business License"
                        className="w-full h-32 object-cover rounded"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Pharmacy License</label>
                    <div className="mt-1 border border-gray-300 rounded-lg p-4">
                      <img
                        src={selectedPharmacy?.documents?.pharmacyLicense || "/placeholder.svg"}
                        alt="Pharmacy License"
                        className="w-full h-32 object-cover rounded"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-600">Owner Photo</label>
                    <div className="mt-1 border border-gray-300 rounded-lg p-4">
                      <img
                        src={selectedPharmacy?.documents?.ownerPhoto || "/placeholder.svg"}
                        alt="Owner Photo"
                        className="w-full h-32 object-cover rounded"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {selectedPharmacy.status === "PENDING" && (
              <div className="flex items-center justify-end space-x-3 mt-6 pt-6 border-t border-gray-200">
                <button
                  onClick={() => handleKYCAction(selectedPharmacy.id, "reject")}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Reject
                </button>
                <button
                  onClick={() => handleKYCAction(selectedPharmacy.id, "approve")}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Approve
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
