"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle, ShoppingCart, DollarSign, Eye, UserCheck, UserX, Package } from "lucide-react"

interface GroceryStats {
  totalStores: number
  activeStores: number
  pendingApproval: number
  totalRevenue: number
  totalProducts: number
  totalOrders: number
}

interface GroceryStore {
  id: string
  storeName: string
  email: string
  phone: string
  address: string
  storeType: string[]
  status: "PENDING" | "APPROVED" | "REJECTED" | "SUSPENDED"
  rating: number
  totalOrders: number
  revenue: number
  totalProducts: number
  isVerified: boolean
  createdAt: string
  lastActive: string
  deliveryFee: number
  minOrderAmount: number
}

export default function GroceryManagementPage() {
  const [stats, setStats] = useState<GroceryStats | null>(null)
  const [stores, setStores] = useState<GroceryStore[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("ALL")
  const [selectedStore, setSelectedStore] = useState<GroceryStore | null>(null)

  useEffect(() => {
    fetchGroceryStats()
    fetchStores()
  }, [])

  const fetchGroceryStats = async () => {
    try {
      const response = await fetch("/api/admin/modules/grocery/stats")
      const data = await response.json()
      setStats(data)
    } catch (error) {
      console.error("Error fetching grocery stats:", error)
    }
  }

  const fetchStores = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/admin/modules/grocery/list")
      const data = await response.json()
      setStores(data.stores || [])
    } catch (error) {
      console.error("Error fetching stores:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleStatusChange = async (storeId: string, newStatus: string) => {
    try {
      const response = await fetch(`/api/admin/modules/grocery/${storeId}/status`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status: newStatus }),
      })

      if (response.ok) {
        fetchStores()
        fetchGroceryStats()
      }
    } catch (error) {
      console.error("Error updating store status:", error)
    }
  }

  const filteredStores = stores.filter((store) => {
    const matchesSearch =
      store.storeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      store.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      store.phone.includes(searchTerm)
    const matchesStatus = statusFilter === "ALL" || store.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    const variants = {
      PENDING: "secondary",
      APPROVED: "default",
      REJECTED: "destructive",
      SUSPENDED: "outline",
    }
    return <Badge variant={variants[status as keyof typeof variants] as any}>{status}</Badge>
  }

  const getStoreTypeBadge = (type: string) => {
    const colors = {
      Organic: "bg-green-100 text-green-800",
      Supermarket: "bg-blue-100 text-blue-800",
      Convenience: "bg-orange-100 text-orange-800",
      Specialty: "bg-purple-100 text-purple-800",
    }
    return (
      <span
        className={`px-2 py-1 rounded-full text-xs ${colors[type as keyof typeof colors] || "bg-gray-100 text-gray-800"}`}
      >
        {type}
      </span>
    )
  }

  if (loading && !stats) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Grocery Store Management</h1>
          <p className="text-muted-foreground">Manage grocery stores, products, and orders</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Stores</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalStores || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Stores</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.activeStores || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalProducts?.toLocaleString() || 0}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₦{stats?.totalRevenue?.toLocaleString() || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Stores Table */}
      <Card>
        <CardHeader>
          <CardTitle>Grocery Stores</CardTitle>
          <CardDescription>Manage and monitor all grocery stores</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-4">
            <Input
              placeholder="Search stores..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Status</SelectItem>
                <SelectItem value="PENDING">Pending</SelectItem>
                <SelectItem value="APPROVED">Approved</SelectItem>
                <SelectItem value="REJECTED">Rejected</SelectItem>
                <SelectItem value="SUSPENDED">Suspended</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Store</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Products</TableHead>
                <TableHead>Orders</TableHead>
                <TableHead>Revenue</TableHead>
                <TableHead>Min Order</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStores.map((store) => (
                <TableRow key={store.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{store.storeName}</div>
                      <div className="text-sm text-muted-foreground">{store.email}</div>
                      <div className="text-sm text-muted-foreground">{store.phone}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {store.storeType.slice(0, 2).map((type, i) => (
                        <div key={i}>{getStoreTypeBadge(type)}</div>
                      ))}
                      {store.storeType.length > 2 && (
                        <Badge variant="outline" className="text-xs">
                          +{store.storeType.length - 2}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>{getStatusBadge(store.status)}</TableCell>
                  <TableCell>{store.totalProducts.toLocaleString()}</TableCell>
                  <TableCell>{store.totalOrders.toLocaleString()}</TableCell>
                  <TableCell>₦{store.revenue.toLocaleString()}</TableCell>
                  <TableCell>₦{store.minOrderAmount.toLocaleString()}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm" onClick={() => setSelectedStore(store)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl">
                          <DialogHeader>
                            <DialogTitle>Store Details</DialogTitle>
                            <DialogDescription>View and manage store information</DialogDescription>
                          </DialogHeader>
                          {selectedStore && (
                            <StoreDetailsModal store={selectedStore} onStatusChange={handleStatusChange} />
                          )}
                        </DialogContent>
                      </Dialog>

                      {store.status === "PENDING" && (
                        <>
                          <Button variant="outline" size="sm" onClick={() => handleStatusChange(store.id, "APPROVED")}>
                            <UserCheck className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm" onClick={() => handleStatusChange(store.id, "REJECTED")}>
                            <UserX className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

function StoreDetailsModal({
  store,
  onStatusChange,
}: {
  store: GroceryStore
  onStatusChange: (id: string, status: string) => void
}) {
  return (
    <Tabs defaultValue="profile" className="w-full">
      <TabsList className="grid w-full grid-cols-4">
        <TabsTrigger value="profile">Profile</TabsTrigger>
        <TabsTrigger value="products">Products</TabsTrigger>
        <TabsTrigger value="orders">Orders</TabsTrigger>
        <TabsTrigger value="analytics">Analytics</TabsTrigger>
      </TabsList>

      <TabsContent value="profile" className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium">Store Name</label>
            <p className="text-sm text-muted-foreground">{store.storeName}</p>
          </div>
          <div>
            <label className="text-sm font-medium">Email</label>
            <p className="text-sm text-muted-foreground">{store.email}</p>
          </div>
          <div>
            <label className="text-sm font-medium">Phone</label>
            <p className="text-sm text-muted-foreground">{store.phone}</p>
          </div>
          <div>
            <label className="text-sm font-medium">Address</label>
            <p className="text-sm text-muted-foreground">{store.address}</p>
          </div>
          <div>
            <label className="text-sm font-medium">Store Types</label>
            <div className="flex flex-wrap gap-1 mt-1">
              {store.storeType.map((type, i) => (
                <div key={i}>{getStoreTypeBadge(type)}</div>
              ))}
            </div>
          </div>
          <div>
            <label className="text-sm font-medium">Delivery Fee</label>
            <p className="text-sm text-muted-foreground">₦{store.deliveryFee}</p>
          </div>
          <div>
            <label className="text-sm font-medium">Status</label>
            <div className="mt-1">{getStatusBadge(store.status)}</div>
          </div>
          <div>
            <label className="text-sm font-medium">Joined</label>
            <p className="text-sm text-muted-foreground">{new Date(store.createdAt).toLocaleDateString()}</p>
          </div>
        </div>

        <div className="flex gap-2 pt-4">
          <Button onClick={() => onStatusChange(store.id, "APPROVED")} disabled={store.status === "APPROVED"}>
            Approve
          </Button>
          <Button
            variant="outline"
            onClick={() => onStatusChange(store.id, "REJECTED")}
            disabled={store.status === "REJECTED"}
          >
            Reject
          </Button>
          <Button
            variant="destructive"
            onClick={() => onStatusChange(store.id, "SUSPENDED")}
            disabled={store.status === "SUSPENDED"}
          >
            Suspend
          </Button>
        </div>
      </TabsContent>

      <TabsContent value="products" className="space-y-4">
        <div className="text-center py-8">
          <p className="text-muted-foreground">Product management coming soon...</p>
        </div>
      </TabsContent>

      <TabsContent value="orders" className="space-y-4">
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Total Orders</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{store.totalOrders}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₦{store.revenue.toLocaleString()}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Products</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{store.totalProducts}</div>
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      <TabsContent value="analytics" className="space-y-4">
        <div className="text-center py-8">
          <p className="text-muted-foreground">Analytics dashboard coming soon...</p>
        </div>
      </TabsContent>
    </Tabs>
  )
}

function getStatusBadge(status: string) {
  const variants = {
    PENDING: "secondary",
    APPROVED: "default",
    REJECTED: "destructive",
    SUSPENDED: "outline",
  }
  return <Badge variant={variants[status as keyof typeof variants] as any}>{status}</Badge>
}

function getStoreTypeBadge(type: string) {
  const colors = {
    Organic: "bg-green-100 text-green-800",
    Supermarket: "bg-blue-100 text-blue-800",
    Convenience: "bg-orange-100 text-orange-800",
    Specialty: "bg-purple-100 text-purple-800",
  }
  return (
    <span
      className={`px-2 py-1 rounded-full text-xs ${colors[type as keyof typeof colors] || "bg-gray-100 text-gray-800"}`}
    >
      {type}
    </span>
  )
}
