"use client"

import { useState, useEffect } from "react"
import {
  Globe,
  Shield,
  Bell,
  CreditCard,
  Database,
  Mail,
  Smartphone,
  DollarSign,
  Percent,
  Save,
  RefreshCw,
  AlertTriangle,
} from "lucide-react"

interface SystemSettings {
  general: {
    appName: string
    appVersion: string
    timezone: string
    language: string
    currency: string
    dateFormat: string
    maintenanceMode: boolean
    maintenanceMessage: string
  }
  security: {
    passwordPolicy: {
      minLength: number
      requireUppercase: boolean
      requireLowercase: boolean
      requireNumbers: boolean
      requireSpecialChars: boolean
      maxAge: number
    }
    sessionTimeout: number
    maxLoginAttempts: number
    lockoutDuration: number
    twoFactorRequired: boolean
    ipWhitelist: string[]
  }
  notifications: {
    emailEnabled: boolean
    smsEnabled: boolean
    pushEnabled: boolean
    emailProvider: string
    smsProvider: string
    defaultSender: string
    templates: {
      welcome: string
      orderConfirmation: string
      passwordReset: string
    }
  }
  payments: {
    defaultCurrency: string
    commissionRates: {
      pharmacy: number
      autoParts: number
      food: number
      grocery: number
      riding: number
    }
    paymentMethods: string[]
    minimumWithdrawal: number
    withdrawalFee: number
    processingTime: string
  }
  modules: {
    pharmacy: {
      enabled: boolean
      autoApproval: boolean
      requirePrescription: boolean
      deliveryRadius: number
    }
    autoParts: {
      enabled: boolean
      autoApproval: boolean
      warrantyRequired: boolean
      returnPeriod: number
    }
    food: {
      enabled: boolean
      autoApproval: boolean
      maxDeliveryTime: number
      qualityChecks: boolean
    }
    grocery: {
      enabled: boolean
      autoApproval: boolean
      freshnessPeriod: number
      bulkOrders: boolean
    }
    riding: {
      enabled: boolean
      autoApproval: boolean
      backgroundCheck: boolean
      insuranceRequired: boolean
    }
  }
}

export default function SystemSettings() {
  const [settings, setSettings] = useState<SystemSettings | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [activeTab, setActiveTab] = useState("general")
  const [hasChanges, setHasChanges] = useState(false)

  useEffect(() => {
    fetchSettings()
  }, [])

  const fetchSettings = async () => {
    try {
      const response = await fetch("/api/admin/settings")
      const data = await response.json()
      console.log(data)
      setSettings(data.settings)
    } catch (error) {
      console.error("Failed to fetch settings:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSaveSettings = async () => {
    setSaving(true)
    try {
      const response = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      })

      if (response.ok) {
        setHasChanges(false)
        // Show success message
      }
    } catch (error) {
      console.error("Failed to save settings:", error)
    } finally {
      setSaving(false)
    }
  }

  const updateSettings = (section: string, field: string, value: any) => {
    if (!settings) return

    setSettings({
      ...settings,
      [section]: {
        ...settings[section as keyof SystemSettings],
        [field]: value,
      },
    })
    setHasChanges(true)
  }

  const updateNestedSettings = (section: string, subsection: string, field: string, value: any) => {
    if (!settings) return

    setSettings({
      ...settings,
      [section]: {
        ...settings[section as keyof SystemSettings],
        [subsection]: {
          ...(settings[section as keyof SystemSettings] as any)[subsection],
          [field]: value,
        },
      },
    })
    setHasChanges(true)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    )
  }

  if (!settings) return null

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">System Settings</h1>
          <p className="text-gray-600 mt-1">Configure system-wide settings and preferences</p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={fetchSettings}
            className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </button>
          <button
            onClick={handleSaveSettings}
            disabled={!hasChanges || saving}
            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
          >
            <Save className="h-4 w-4 mr-2" />
            {saving ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>

      {/* Changes Alert */}
      {hasChanges && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2" />
            <span className="text-yellow-800">You have unsaved changes. Don't forget to save!</span>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="bg-white rounded-lg border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: "general", label: "General", icon: <Globe className="h-4 w-4" /> },
              { id: "security", label: "Security", icon: <Shield className="h-4 w-4" /> },
              { id: "notifications", label: "Notifications", icon: <Bell className="h-4 w-4" /> },
              { id: "payments", label: "Payments", icon: <CreditCard className="h-4 w-4" /> },
              { id: "modules", label: "Modules", icon: <Database className="h-4 w-4" /> },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                  activeTab === tab.id
                    ? "border-green-500 text-green-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {/* General Settings */}
          {activeTab === "general" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">General Configuration</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">App Name</label>
                    <input
                      type="text"
                      value={settings.general.appName}
                      onChange={(e) => updateSettings("general", "appName", e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">App Version</label>
                    <input
                      type="text"
                      value={settings.general.appVersion}
                      onChange={(e) => updateSettings("general", "appVersion", e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Timezone</label>
                    <select
                      value={settings.general.timezone}
                      onChange={(e) => updateSettings("general", "timezone", e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    >
                      <option value="UTC">UTC</option>
                      <option value="Africa/Lagos">Africa/Lagos</option>
                      <option value="America/New_York">America/New_York</option>
                      <option value="Europe/London">Europe/London</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Default Currency</label>
                    <select
                      value={settings.general.currency}
                      onChange={(e) => updateSettings("general", "currency", e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    >
                      <option value="NGN">Nigerian Naira (₦)</option>
                      <option value="USD">US Dollar ($)</option>
                      <option value="EUR">Euro (€)</option>
                      <option value="GBP">British Pound (£)</option>
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Maintenance Mode</h3>
                <div className="space-y-4">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={settings.general.maintenanceMode}
                      onChange={(e) => updateSettings("general", "maintenanceMode", e.target.checked)}
                      className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">Enable maintenance mode</span>
                  </label>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Maintenance Message</label>
                    <textarea
                      value={settings.general.maintenanceMessage}
                      onChange={(e) => updateSettings("general", "maintenanceMessage", e.target.value)}
                      rows={3}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                      placeholder="Message to display during maintenance"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Security Settings */}
          {activeTab === "security" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Password Policy</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Minimum Length</label>
                    <input
                      type="number"
                      value={settings.security.passwordPolicy.minLength}
                      onChange={(e) =>
                        updateNestedSettings("security", "passwordPolicy", "minLength", Number(e.target.value))
                      }
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Max Age (days)</label>
                    <input
                      type="number"
                      value={settings.security.passwordPolicy.maxAge}
                      onChange={(e) =>
                        updateNestedSettings("security", "passwordPolicy", "maxAge", Number(e.target.value))
                      }
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  {[
                    { key: "requireUppercase", label: "Require uppercase letters" },
                    { key: "requireLowercase", label: "Require lowercase letters" },
                    { key: "requireNumbers", label: "Require numbers" },
                    { key: "requireSpecialChars", label: "Require special characters" },
                  ].map((item) => (
                    <label key={item.key} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={
                          settings.security.passwordPolicy[
                            item.key as keyof typeof settings.security.passwordPolicy
                          ] as boolean
                        }
                        onChange={(e) => updateNestedSettings("security", "passwordPolicy", item.key, e.target.checked)}
                        className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">{item.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Session & Login Security</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Session Timeout (minutes)</label>
                    <input
                      type="number"
                      value={settings.security.sessionTimeout}
                      onChange={(e) => updateSettings("security", "sessionTimeout", Number(e.target.value))}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Max Login Attempts</label>
                    <input
                      type="number"
                      value={settings.security.maxLoginAttempts}
                      onChange={(e) => updateSettings("security", "maxLoginAttempts", Number(e.target.value))}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Lockout Duration (minutes)</label>
                    <input
                      type="number"
                      value={settings.security.lockoutDuration}
                      onChange={(e) => updateSettings("security", "lockoutDuration", Number(e.target.value))}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                </div>
                <div className="mt-4">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={settings.security.twoFactorRequired}
                      onChange={(e) => updateSettings("security", "twoFactorRequired", e.target.checked)}
                      className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">Require two-factor authentication for all admins</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* Notification Settings */}
          {activeTab === "notifications" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Notification Channels</h3>
                <div className="space-y-4">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={settings.notifications.emailEnabled}
                      onChange={(e) => updateSettings("notifications", "emailEnabled", e.target.checked)}
                      className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                    />
                    <Mail className="h-4 w-4 ml-2 mr-1" />
                    <span className="text-sm text-gray-700">Email notifications</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={settings.notifications.smsEnabled}
                      onChange={(e) => updateSettings("notifications", "smsEnabled", e.target.checked)}
                      className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                    />
                    <Smartphone className="h-4 w-4 ml-2 mr-1" />
                    <span className="text-sm text-gray-700">SMS notifications</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={settings.notifications.pushEnabled}
                      onChange={(e) => updateSettings("notifications", "pushEnabled", e.target.checked)}
                      className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                    />
                    <Bell className="h-4 w-4 ml-2 mr-1" />
                    <span className="text-sm text-gray-700">Push notifications</span>
                  </label>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Provider Configuration</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email Provider</label>
                    <select
                      value={settings.notifications.emailProvider}
                      onChange={(e) => updateSettings("notifications", "emailProvider", e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    >
                      <option value="sendgrid">SendGrid</option>
                      <option value="mailgun">Mailgun</option>
                      <option value="ses">Amazon SES</option>
                      <option value="smtp">Custom SMTP</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">SMS Provider</label>
                    <select
                      value={settings.notifications.smsProvider}
                      onChange={(e) => updateSettings("notifications", "smsProvider", e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    >
                      <option value="twilio">Twilio</option>
                      <option value="nexmo">Nexmo</option>
                      <option value="africas_talking">Africa's Talking</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Default Sender</label>
                    <input
                      type="text"
                      value={settings.notifications.defaultSender}
                      onChange={(e) => updateSettings("notifications", "defaultSender", e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                      placeholder="Kilo Super App"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Payment Settings */}
          {activeTab === "payments" && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Commission Rates (%)</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {Object.entries(settings.payments.commissionRates).map(([module, rate]) => (
                    <div key={module}>
                      <label className="block text-sm font-medium text-gray-700 mb-1 capitalize">
                        {module.replace(/([A-Z])/g, " $1")}
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          step="0.1"
                          value={rate}
                          onChange={(e) =>
                            updateNestedSettings("payments", "commissionRates", module, Number(e.target.value))
                          }
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 pr-8 focus:ring-2 focus:ring-green-500"
                        />
                        <Percent className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Withdrawal Settings</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Minimum Withdrawal</label>
                    <div className="relative">
                      <input
                        type="number"
                        value={settings.payments.minimumWithdrawal}
                        onChange={(e) => updateSettings("payments", "minimumWithdrawal", Number(e.target.value))}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 pl-8 focus:ring-2 focus:ring-green-500"
                      />
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Withdrawal Fee</label>
                    <div className="relative">
                      <input
                        type="number"
                        value={settings.payments.withdrawalFee}
                        onChange={(e) => updateSettings("payments", "withdrawalFee", Number(e.target.value))}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 pl-8 focus:ring-2 focus:ring-green-500"
                      />
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Processing Time</label>
                    <select
                      value={settings.payments.processingTime}
                      onChange={(e) => updateSettings("payments", "processingTime", e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                    >
                      <option value="instant">Instant</option>
                      <option value="1-3 business days">1-3 business days</option>
                      <option value="3-5 business days">3-5 business days</option>
                      <option value="5-7 business days">5-7 business days</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Module Settings */}
          {activeTab === "modules" && (
            <div className="space-y-6">
              {Object.entries(settings.modules).map(([moduleName, moduleSettings]) => (
                <div key={moduleName} className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 capitalize">
                      {moduleName.replace(/([A-Z])/g, " $1")} Module
                    </h3>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={moduleSettings.enabled}
                        onChange={(e) => updateNestedSettings("modules", moduleName, "enabled", e.target.checked)}
                        className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">Enabled</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={moduleSettings.autoApproval}
                        onChange={(e) => updateNestedSettings("modules", moduleName, "autoApproval", e.target.checked)}
                        className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">Auto-approve vendors</span>
                    </label>

                    {/* Module-specific settings */}
                    {moduleName === "pharmacy" && (
                      <>
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={moduleSettings.requirePrescription}
                            onChange={(e) =>
                              updateNestedSettings("modules", moduleName, "requirePrescription", e.target.checked)
                            }
                            className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                          />
                          <span className="ml-2 text-sm text-gray-700">Require prescription</span>
                        </label>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Radius (km)</label>
                          <input
                            type="number"
                            value={moduleSettings.deliveryRadius}
                            onChange={(e) =>
                              updateNestedSettings("modules", moduleName, "deliveryRadius", Number(e.target.value))
                            }
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500"
                          />
                        </div>
                      </>
                    )}

                    {moduleName === "riding" && (
                      <>
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={moduleSettings.backgroundCheck}
                            onChange={(e) =>
                              updateNestedSettings("modules", moduleName, "backgroundCheck", e.target.checked)
                            }
                            className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                          />
                          <span className="ml-2 text-sm text-gray-700">Background check required</span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={moduleSettings.insuranceRequired}
                            onChange={(e) =>
                              updateNestedSettings("modules", moduleName, "insuranceRequired", e.target.checked)
                            }
                            className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                          />
                          <span className="ml-2 text-sm text-gray-700">Insurance required</span>
                        </label>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
