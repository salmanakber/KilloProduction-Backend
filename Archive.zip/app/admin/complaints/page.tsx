"use client"

import { useState, useEffect } from "react"
import {
  Search,
  Filter,
  Download,
  Plus,
  MessageSquare,
  Clock,
  CheckCircle,
  AlertTriangle,
  User,
  Calendar,
  Tag,
  Send,
  Paperclip,
  MoreHorizontal,
} from "lucide-react"

interface Complaint {
  id: string
  title: string
  description: string
  category: "order" | "delivery" | "payment" | "vendor" | "app" | "other"
  priority: "low" | "medium" | "high" | "urgent"
  status: "pending" | "in_progress" | "resolved" | "escalated" | "closed"
  customerName: string
  customerEmail: string
  customerPhone: string
  vendorName?: string
  orderId?: string
  createdAt: string
  updatedAt: string
  assignedTo?: string
  responseTime?: number
  resolutionTime?: number
}

interface ComplaintMessage {
  id: string
  complaintId: string
  sender: "customer" | "admin" | "vendor"
  senderName: string
  message: string
  timestamp: string
  attachments?: string[]
}

export default function ComplaintsManagement() {
  const [complaints, setComplaints] = useState<Complaint[]>([])
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null)
  const [complaintMessages, setComplaintMessages] = useState<ComplaintMessage[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedPriority, setSelectedPriority] = useState("all")
  const [showFilters, setShowFilters] = useState(false)
  const [showComplaintDetail, setShowComplaintDetail] = useState(false)
  const [newMessage, setNewMessage] = useState("")

  useEffect(() => {
    fetchComplaints()
  }, [])

  const fetchComplaints = async () => {
    try {
      // Mock data - replace with actual API call
      const mockComplaints: Complaint[] = [
        {
          id: "1",
          title: "Order not delivered",
          description:
            "I placed an order 3 days ago but it has not been delivered yet. The tracking shows it was picked up but no updates since then.",
          category: "delivery",
          priority: "high",
          status: "pending",
          customerName: "John Doe",
          customerEmail: "john@example.com",
          customerPhone: "+234 801 234 5678",
          vendorName: "MediCare Pharmacy",
          orderId: "ORD-001",
          createdAt: "2024-01-20T10:30:00Z",
          updatedAt: "2024-01-20T10:30:00Z",
          responseTime: 0,
        },
        {
          id: "2",
          title: "Wrong medication received",
          description:
            "I ordered Paracetamol but received a different medication. This is very concerning as it could be dangerous.",
          category: "order",
          priority: "urgent",
          status: "in_progress",
          customerName: "Sarah Johnson",
          customerEmail: "sarah@example.com",
          customerPhone: "+234 802 345 6789",
          vendorName: "HealthPlus Pharmacy",
          orderId: "ORD-002",
          createdAt: "2024-01-19T14:15:00Z",
          updatedAt: "2024-01-20T09:00:00Z",
          assignedTo: "Admin User",
          responseTime: 2.5,
        },
        {
          id: "3",
          title: "Payment deducted but order cancelled",
          description: "My payment was deducted from my account but the order was cancelled. I need a refund.",
          category: "payment",
          priority: "medium",
          status: "resolved",
          customerName: "Ahmed Hassan",
          customerEmail: "ahmed@example.com",
          customerPhone: "+234 803 456 7890",
          orderId: "ORD-003",
          createdAt: "2024-01-18T16:45:00Z",
          updatedAt: "2024-01-19T11:30:00Z",
          assignedTo: "Finance Team",
          responseTime: 1.2,
          resolutionTime: 18.8,
        },
      ]
      setComplaints(mockComplaints)
      setLoading(false)
    } catch (error) {
      console.error("Error fetching complaints:", error)
      setLoading(false)
    }
  }

  const fetchComplaintMessages = async (complaintId: string) => {
    try {
      // Mock data - replace with actual API call
      const mockMessages: ComplaintMessage[] = [
        {
          id: "1",
          complaintId,
          sender: "customer",
          senderName: "John Doe",
          message:
            "I placed an order 3 days ago but it has not been delivered yet. The tracking shows it was picked up but no updates since then.",
          timestamp: "2024-01-20T10:30:00Z",
        },
        {
          id: "2",
          complaintId,
          sender: "admin",
          senderName: "Support Team",
          message: "Thank you for contacting us. We are looking into your order and will update you shortly.",
          timestamp: "2024-01-20T11:00:00Z",
        },
      ]
      setComplaintMessages(mockMessages)
    } catch (error) {
      console.error("Error fetching complaint messages:", error)
    }
  }

  const filteredComplaints = complaints.filter((complaint) => {
    const matchesSearch =
      complaint.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      complaint.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      complaint.orderId?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || complaint.category === selectedCategory
    const matchesStatus = selectedStatus === "all" || complaint.status === selectedStatus
    const matchesPriority = selectedPriority === "all" || complaint.priority === selectedPriority

    return matchesSearch && matchesCategory && matchesStatus && matchesPriority
  })

  const handleComplaintClick = (complaint: Complaint) => {
    setSelectedComplaint(complaint)
    setShowComplaintDetail(true)
    fetchComplaintMessages(complaint.id)
  }

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedComplaint) return

    const message: ComplaintMessage = {
      id: Date.now().toString(),
      complaintId: selectedComplaint.id,
      sender: "admin",
      senderName: "Admin User",
      message: newMessage,
      timestamp: new Date().toISOString(),
    }

    setComplaintMessages((prev) => [...prev, message])
    setNewMessage("")
  }

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "order":
        return "bg-blue-100 text-blue-800"
      case "delivery":
        return "bg-orange-100 text-orange-800"
      case "payment":
        return "bg-green-100 text-green-800"
      case "vendor":
        return "bg-purple-100 text-purple-800"
      case "app":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent":
        return "bg-red-100 text-red-800"
      case "high":
        return "bg-orange-100 text-orange-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "in_progress":
        return "bg-blue-100 text-blue-800"
      case "resolved":
        return "bg-green-100 text-green-800"
      case "escalated":
        return "bg-red-100 text-red-800"
      case "closed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="w-4 h-4 text-yellow-600" />
      case "in_progress":
        return <AlertTriangle className="w-4 h-4 text-blue-600" />
      case "resolved":
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case "escalated":
        return <AlertTriangle className="w-4 h-4 text-red-600" />
      default:
        return <Clock className="w-4 h-4 text-gray-600" />
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Complaints Management</h1>
          <p className="text-gray-600 mt-1">Handle and resolve customer complaints</p>
        </div>
        <div className="flex items-center space-x-3">
          <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download className="w-4 h-4 mr-2" />
            Export
          </button>
          <button className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
            <Plus className="w-4 h-4 mr-2" />
            New Complaint
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <Clock className="w-8 h-8 text-yellow-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Pending</p>
              <p className="text-2xl font-bold text-gray-900">
                {complaints.filter((c) => c.status === "pending").length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <AlertTriangle className="w-8 h-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">In Progress</p>
              <p className="text-2xl font-bold text-gray-900">
                {complaints.filter((c) => c.status === "in_progress").length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <CheckCircle className="w-8 h-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Resolved</p>
              <p className="text-2xl font-bold text-gray-900">
                {complaints.filter((c) => c.status === "resolved").length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <AlertTriangle className="w-8 h-8 text-red-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Urgent</p>
              <p className="text-2xl font-bold text-gray-900">
                {complaints.filter((c) => c.priority === "urgent").length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search complaints..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent w-64"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              <Filter className="w-4 h-4 mr-2" />
              Filters
            </button>
          </div>
        </div>

        {showFilters && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="all">All Categories</option>
                  <option value="order">Order</option>
                  <option value="delivery">Delivery</option>
                  <option value="payment">Payment</option>
                  <option value="vendor">Vendor</option>
                  <option value="app">App</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="all">All Status</option>
                  <option value="pending">Pending</option>
                  <option value="in_progress">In Progress</option>
                  <option value="resolved">Resolved</option>
                  <option value="escalated">Escalated</option>
                  <option value="closed">Closed</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Priority</label>
                <select
                  value={selectedPriority}
                  onChange={(e) => setSelectedPriority(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="all">All Priorities</option>
                  <option value="urgent">Urgent</option>
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Assigned To</label>
                <select className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent">
                  <option value="all">All Staff</option>
                  <option value="unassigned">Unassigned</option>
                  <option value="admin">Admin User</option>
                  <option value="support">Support Team</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Complaints List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Complaints ({filteredComplaints.length})</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {filteredComplaints.map((complaint) => (
            <div
              key={complaint.id}
              className="p-6 hover:bg-gray-50 cursor-pointer"
              onClick={() => handleComplaintClick(complaint)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h4 className="text-lg font-medium text-gray-900">{complaint.title}</h4>
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getCategoryColor(complaint.category)}`}
                    >
                      {complaint.category}
                    </span>
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(complaint.priority)}`}
                    >
                      {complaint.priority}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-3 line-clamp-2">{complaint.description}</p>
                  <div className="flex items-center space-x-6 text-sm text-gray-500">
                    <div className="flex items-center">
                      <User className="w-4 h-4 mr-1" />
                      {complaint.customerName}
                    </div>
                    {complaint.orderId && (
                      <div className="flex items-center">
                        <Tag className="w-4 h-4 mr-1" />
                        {complaint.orderId}
                      </div>
                    )}
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      {new Date(complaint.createdAt).toLocaleDateString()}
                    </div>
                    {complaint.assignedTo && (
                      <div className="flex items-center">
                        <User className="w-4 h-4 mr-1" />
                        Assigned to {complaint.assignedTo}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="flex items-center">
                    {getStatusIcon(complaint.status)}
                    <span
                      className={`ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(complaint.status)}`}
                    >
                      {complaint.status.replace("_", " ")}
                    </span>
                  </div>
                  <button className="text-gray-400 hover:text-gray-600">
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredComplaints.length === 0 && (
          <div className="text-center py-12">
            <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No complaints found</h3>
            <p className="text-gray-500">Try adjusting your search or filter criteria.</p>
          </div>
        )}
      </div>

      {/* Complaint Detail Modal */}
      {showComplaintDetail && selectedComplaint && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div
              className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75"
              onClick={() => setShowComplaintDetail(false)}
            ></div>

            <div className="inline-block w-full max-w-4xl my-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-xl rounded-lg">
              <div className="flex h-96">
                {/* Complaint Details */}
                <div className="w-1/2 p-6 border-r border-gray-200">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">Complaint Details</h3>
                    <button onClick={() => setShowComplaintDetail(false)} className="text-gray-400 hover:text-gray-600">
                      ×
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-900">{selectedComplaint.title}</h4>
                      <div className="flex items-center space-x-2 mt-1">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getCategoryColor(selectedComplaint.category)}`}
                        >
                          {selectedComplaint.category}
                        </span>
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(selectedComplaint.priority)}`}
                        >
                          {selectedComplaint.priority}
                        </span>
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(selectedComplaint.status)}`}
                        >
                          {selectedComplaint.status.replace("_", " ")}
                        </span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700">Description</label>
                      <p className="mt-1 text-sm text-gray-600">{selectedComplaint.description}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Customer</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedComplaint.customerName}</p>
                        <p className="text-sm text-gray-500">{selectedComplaint.customerEmail}</p>
                        <p className="text-sm text-gray-500">{selectedComplaint.customerPhone}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Order ID</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedComplaint.orderId || "N/A"}</p>
                        {selectedComplaint.vendorName && (
                          <>
                            <label className="block text-sm font-medium text-gray-700 mt-2">Vendor</label>
                            <p className="mt-1 text-sm text-gray-900">{selectedComplaint.vendorName}</p>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Created</label>
                        <p className="mt-1 text-sm text-gray-900">
                          {new Date(selectedComplaint.createdAt).toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Assigned To</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedComplaint.assignedTo || "Unassigned"}</p>
                      </div>
                    </div>

                    {selectedComplaint.responseTime && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Response Time</label>
                        <p className="mt-1 text-sm text-gray-900">{selectedComplaint.responseTime} hours</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Messages */}
                <div className="w-1/2 flex flex-col">
                  <div className="p-6 border-b border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900">Messages</h3>
                  </div>

                  <div className="flex-1 p-6 overflow-y-auto">
                    <div className="space-y-4">
                      {complaintMessages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.sender === "admin" ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                              message.sender === "admin" ? "bg-green-600 text-white" : "bg-gray-100 text-gray-900"
                            }`}
                          >
                            <p className="text-sm">{message.message}</p>
                            <p
                              className={`text-xs mt-1 ${
                                message.sender === "admin" ? "text-green-100" : "text-gray-500"
                              }`}
                            >
                              {message.senderName} • {new Date(message.timestamp).toLocaleTimeString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-6 border-t border-gray-200">
                    <div className="flex items-center space-x-2">
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type your response..."
                        className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                      />
                      <button className="text-gray-400 hover:text-gray-600">
                        <Paperclip className="w-5 h-5" />
                      </button>
                      <button
                        onClick={handleSendMessage}
                        className="bg-green-600 text-white p-2 rounded-lg hover:bg-green-700"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
