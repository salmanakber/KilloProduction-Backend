import { PrismaClient } from "@prisma/client"
import bcrypt from "bcryptjs"

const prisma = new PrismaClient()

async function main() {
  console.log("🌱 Starting database seeding...")

  // Create admin user
  const adminUser = await prisma.user.create({
    data: {
      phone: "+1234567890",
      email: "admin@kilosuperapp.com",
      name: "Super Admin",
      role: "SUPER_ADMIN",
      password: bcrypt.hashSync("admin123", 10),
      isVerified: true,
      userProfile: {
        create: {
          firstName: "Super",
          lastName: "Admin",
        },
      },
      userSettings: {
        create: {},
      },
      wallet: {
        create: {
          balance: 1000.0,
        },
      },
    },
  })

  // Create sample customers
  const customers = await Promise.all([
    prisma.user.create({
      data: {
        phone: "+1234567891",
        email: "john.customer@example.com",
        name: "John Customer",
        role: "CUSTOMER",
        password: bcrypt.hashSync("customer123", 10),
        isVerified: true,
        userProfile: {
          create: {
            firstName: "John",
            lastName: "Customer",
            gender: "MALE",
          },
        },
        userSettings: {
          create: {},
        },
        wallet: {
          create: {
            balance: 500.0,
          },
        },
        addresses: {
          create: [
            {
              type: "HOME",
              title: "Home",
              street: "123 Main Street",
              city: "New York",
              state: "NY",
              country: "USA",
              postalCode: "10001",
              latitude: 40.7128,
              longitude: -74.006,
              isDefault: true,
            },
            {
              type: "WORK",
              title: "Office",
              street: "456 Business Ave",
              city: "New York",
              state: "NY",
              country: "USA",
              postalCode: "10002",
              latitude: 40.7589,
              longitude: -73.9851,
            },
          ],
        },
      },
    }),
    prisma.user.create({
      data: {
        phone: "+1234567892",
        email: "jane.customer@example.com",
        name: "Jane Customer",
        role: "CUSTOMER",
        password: bcrypt.hashSync("customer123", 10),
        isVerified: true,
        userProfile: {
          create: {
            firstName: "Jane",
            lastName: "Customer",
            gender: "FEMALE",
          },
        },
        userSettings: {
          create: {},
        },
        wallet: {
          create: {
            balance: 750.0,
          },
        },
      },
    }),
  ])

  // Create auto parts vendor
  const autoPartsVendor = await prisma.user.create({
    data: {
      phone: "+1234567893",
      email: "autoparts@example.com",
      name: "Auto Parts Store Owner",
      role: "VENDOR",
      password: bcrypt.hashSync("vendor123", 10),
      isVerified: true,
      userProfile: {
        create: {
          firstName: "Mike",
          lastName: "AutoParts",
        },
      },
      userSettings: {
        create: {},
      },
      autoPartsStore: {
        create: {
          storeName: "Premium Auto Parts",
          description: "Quality auto parts for all vehicle makes and models",
          address: "789 Auto Street, Detroit, MI 48201",
          phone: "+1234567893",
          email: "info@premiumautoparts.com",
          rating: 4.5,
          totalReviews: 150,
          totalOrders: 500,
          isVerified: true,
          deliveryZones: ["Detroit", "Dearborn", "Warren"],
          openingHours: {
            monday: { open: "08:00", close: "18:00" },
            tuesday: { open: "08:00", close: "18:00" },
            wednesday: { open: "08:00", close: "18:00" },
            thursday: { open: "08:00", close: "18:00" },
            friday: { open: "08:00", close: "18:00" },
            saturday: { open: "09:00", close: "17:00" },
            sunday: { open: "10:00", close: "16:00" },
          },
        },
      },
    },
  })

  // Create pharmacy vendor
  const pharmacyVendor = await prisma.user.create({
    data: {
      phone: "+1234567894",
      email: "pharmacy@example.com",
      name: "Pharmacy Owner",
      role: "VENDOR",
      password: bcrypt.hashSync("vendor123", 10),
      isVerified: true,
      userProfile: {
        create: {
          firstName: "Sarah",
          lastName: "PharmD",
        },
      },
      userSettings: {
        create: {},
      },
      pharmacy: {
        create: {
          pharmacyName: "HealthCare Pharmacy",
          licenseNumber: "PH123456789",
          description: "Your trusted neighborhood pharmacy",
          address: "321 Health Ave, Boston, MA 02101",
          phone: "+1234567894",
          email: "info@healthcarepharmacy.com",
          rating: 4.8,
          totalReviews: 200,
          totalOrders: 800,
          isVerified: true,
          is24Hours: false,
          deliveryAvailable: true,
          deliveryZones: ["Boston", "Cambridge", "Somerville"],
          specialties: ["General", "Pediatric", "Geriatric"],
          openingHours: {
            monday: { open: "07:00", close: "22:00" },
            tuesday: { open: "07:00", close: "22:00" },
            wednesday: { open: "07:00", close: "22:00" },
            thursday: { open: "07:00", close: "22:00" },
            friday: { open: "07:00", close: "22:00" },
            saturday: { open: "08:00", close: "20:00" },
            sunday: { open: "09:00", close: "18:00" },
          },
        },
      },
    },
  })

  // Create restaurant vendor
  const restaurantVendor = await prisma.user.create({
    data: {
      phone: "+1234567895",
      email: "restaurant@example.com",
      name: "Restaurant Owner",
      role: "VENDOR",
      password: bcrypt.hashSync("vendor123", 10),
      isVerified: true,
      userProfile: {
        create: {
          firstName: "Tony",
          lastName: "Chef",
        },
      },
      userSettings: {
        create: {},
      },
      restaurant: {
        create: {
          name: "Delicious Bites Restaurant",
          description: "Authentic Italian cuisine with fresh ingredients",
          cuisine: ["Italian", "Mediterranean"],
          address: "555 Food Street, Chicago, IL 60601",
          phone: "+1234567895",
          email: "orders@deliciousbites.com",
          rating: 4.3,
          totalReviews: 300,
          totalOrders: 1200,
          priceRange: "MODERATE",
          deliveryTime: "30-45 mins",
          deliveryFee: 3.99,
          minOrderAmount: 15.0,
          maxDeliveryDistance: 8.0,
          isVerified: true,
          deliveryZones: ["Downtown Chicago", "Loop", "River North"],
          specialDiets: ["Vegetarian", "Gluten-Free"],
          openingHours: {
            monday: { open: "11:00", close: "22:00" },
            tuesday: { open: "11:00", close: "22:00" },
            wednesday: { open: "11:00", close: "22:00" },
            thursday: { open: "11:00", close: "23:00" },
            friday: { open: "11:00", close: "23:00" },
            saturday: { open: "12:00", close: "23:00" },
            sunday: { open: "12:00", close: "21:00" },
          },
        },
      },
    },
  })

  // Create riders
  const riders = await Promise.all([
    prisma.user.create({
      data: {
        phone: "+1234567896",
        email: "rider1@example.com",
        name: "Alex Rider",
        role: "RIDER",
        password: bcrypt.hashSync("rider123", 10),
        isVerified: true,
        userProfile: {
          create: {
            firstName: "Alex",
            lastName: "Rider",
            gender: "MALE",
          },
        },
        userSettings: {
          create: {},
        },
        riderProfile: {
          create: {
            vehicleType: "MOTORCYCLE",
            vehicleBrand: "Honda",
            vehicleModel: "CBR150R",
            vehicleYear: "2022",
            vehicleColor: "Red",
            licensePlate: "ABC123",
            licenseNumber: "DL123456789",
            licenseExpiry: new Date("2025-12-31"),
            modules: ["AUTO_PARTS", "PHARMACY", "FOOD", "GROCERY"],
            isAvailable: true,
            rating: 4.7,
            totalDeliveries: 250,
            totalEarnings: 2500.0,
            isVerified: true,
            deliveryZones: ["Downtown", "Midtown", "Uptown"],
            workingHours: {
              monday: { start: "09:00", end: "18:00" },
              tuesday: { start: "09:00", end: "18:00" },
              wednesday: { start: "09:00", end: "18:00" },
              thursday: { start: "09:00", end: "18:00" },
              friday: { start: "09:00", end: "20:00" },
              saturday: { start: "10:00", end: "20:00" },
              sunday: { start: "12:00", end: "18:00" },
            },
          },
        },
      },
    }),
  ])

  // Create promo codes
  const promoCodes = await Promise.all([
    prisma.promoCode.create({
      data: {
        code: "WELCOME10",
        title: "Welcome Discount",
        description: "10% off your first order",
        type: "PERCENTAGE",
        value: 10,
        minOrderAmount: 25.0,
        maxDiscount: 10.0,
        usageLimit: 1000,
        modules: ["AUTO_PARTS", "PHARMACY", "FOOD", "GROCERY"],
        startsAt: new Date(),
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
      },
    }),
    prisma.promoCode.create({
      data: {
        code: "FREEDEL",
        title: "Free Delivery",
        description: "Free delivery on orders over $30",
        type: "FREE_DELIVERY",
        value: 0,
        minOrderAmount: 30.0,
        usageLimit: 500,
        modules: ["FOOD", "GROCERY"],
        startsAt: new Date(),
        expiresAt: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000), // 60 days
      },
    }),
  ])

  console.log("✅ Database seeding completed successfully!")
  console.log(`Created:`)
  console.log(`- 1 Admin user`)
  console.log(`- 2 Customer users`)
  console.log(`- 3 Vendor users (Auto Parts, Pharmacy, Restaurant)`)
  console.log(`- 1 Rider user`)
  console.log(`- 2 Promo codes`)
}

main()
  .catch((e) => {
    console.error("❌ Error during seeding:", e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
