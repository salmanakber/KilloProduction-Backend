import nodemailer from "nodemailer"
import { prisma } from "@/lib/prisma"
import { total } from "@/lib/total" // Declare the total variable or fix the import

interface EmailOptions {
  to: string | string[]
  subject: string
  html?: string
  text?: string
  from?: string
  attachments?: Array<{
    filename: string
    content: Buffer | string
    contentType?: string
  }>
}

interface BulkEmailOptions {
  recipients: Array<{
    email: string
    name?: string
    customData?: Record<string, any>
  }>
  subject: string
  htmlTemplate: string
  textTemplate?: string
  from?: string
}

interface CampaignEmailContent {
  subject: string
  html: string
  text?: string
  total?: number
  appUrl?: string
  orderNumber?: string
  address?: string
  estimatedDelivery?: string
  resetUrl?: string
  promoTitle?: string
  promoSubtitle?: string
  promoDescription?: string
  discountCode?: string
  discountAmount?: string
  expiryDate?: string
  ctaUrl?: string
  ctaText?: string
}

interface SendEmailOptions {
  to: string | string[]
  subject: string
  html: string
  text?: string
  campaignId?: string
  userId?: string
  from?: string
}

interface SendBulkEmailOptions {
  recipients: Array<{ email: string; data?: Record<string, any> }>
  subjectTemplate: string
  htmlTemplate: string
  textTemplate?: string
  from?: string
}

// Create reusable transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number.parseInt(process.env.SMTP_PORT || "587"),
  secure: process.env.SMTP_SECURE === "true", // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
})

export async function sendEmail({
  to,
  subject,
  html,
  text,
}: {
  to: string
  subject: string
  html: string
  text?: string
}) {
  try {
    await transporter.sendMail({
      from: process.env.DEFAULT_FROM_EMAIL,
      to,
      subject,
      html,
      text,
    })
    console.log(`Email sent to ${to}`)
  } catch (error) {
    console.error(`Error sending email to ${to}:`, error)
    throw new Error("Failed to send email")
  }
}

export async function sendBulkEmail(recipients: string[], subject: string, html: string, text?: string) {
  try {
    const results = await Promise.allSettled(
      recipients.map((to) =>
        transporter.sendMail({
          from: process.env.DEFAULT_FROM_EMAIL,
          to,
          subject,
          html,
          text,
        }),
      ),
    )

    results.forEach((result, index) => {
      if (result.status === "fulfilled") {
        console.log(`Email sent to ${recipients[index]}`)
      } else {
        console.error(`Failed to send email to ${recipients[index]}:`, result.reason)
      }
    })

    console.log(`Bulk email operation completed for ${recipients.length} recipients.`)
  } catch (error) {
    console.error("Error sending bulk email:", error)
    throw new Error("Failed to send bulk email")
  }
}

export async function sendCampaignEmail(
  campaignId: string,
  recipients: Array<{ email: string; name?: string; userId?: string }>,
  content: CampaignEmailContent,
): Promise<{
  campaignId: string
  sent: number
  delivered: number
  failed: number
  errors: Array<{ email: string; error: string }>
}> {
  const results = {
    campaignId,
    sent: 0,
    delivered: 0,
    failed: 0,
    errors: [] as Array<{ email: string; error: string }>,
  }

  for (const recipient of recipients) {
    try {
      // Personalize content
      let personalizedHtml = content.html
      let personalizedText = content.text || ""

      personalizedHtml = personalizedHtml.replace(/\{\{name\}\}/g, recipient.name || "User")
      personalizedHtml = personalizedHtml.replace(/\{\{email\}\}/g, recipient.email)
      personalizedText = personalizedText.replace(/\{\{name\}\}/g, recipient.name || "User")
      personalizedText = personalizedText.replace(/\{\{email\}\}/g, recipient.email)

      // Replace specific variables
      if (content.total !== undefined) {
        personalizedHtml = personalizedHtml.replace(/\{\{total\}\}/g, String(content.total))
        personalizedText = personalizedText.replace(/\{\{total\}\}/g, String(content.total))
      }
      if (content.appUrl) {
        personalizedHtml = personalizedHtml.replace(/\{\{appUrl\}\}/g, content.appUrl)
        personalizedText = personalizedText.replace(/\{\{appUrl\}\}/g, content.appUrl)
      }
      if (content.orderNumber) {
        personalizedHtml = personalizedHtml.replace(/\{\{orderNumber\}\}/g, content.orderNumber)
        personalizedText = personalizedText.replace(/\{\{orderNumber\}\}/g, content.orderNumber)
      }
      if (content.address) {
        personalizedHtml = personalizedHtml.replace(/\{\{address\}\}/g, content.address)
        personalizedText = personalizedText.replace(/\{\{address\}\}/g, content.address)
      }
      if (content.estimatedDelivery) {
        personalizedHtml = personalizedHtml.replace(/\{\{estimatedDelivery\}\}/g, content.estimatedDelivery)
        personalizedText = personalizedText.replace(/\{\{estimatedDelivery\}\}/g, content.estimatedDelivery)
      }
      if (content.resetUrl) {
        personalizedHtml = personalizedHtml.replace(/\{\{resetUrl\}\}/g, content.resetUrl)
        personalizedText = personalizedText.replace(/\{\{resetUrl\}\}/g, content.resetUrl)
      }
      if (content.promoTitle) {
        personalizedHtml = personalizedHtml.replace(/\{\{promoTitle\}\}/g, content.promoTitle)
        personalizedText = personalizedText.replace(/\{\{promoTitle\}\}/g, content.promoTitle)
      }
      if (content.promoSubtitle) {
        personalizedHtml = personalizedHtml.replace(/\{\{promoSubtitle\}\}/g, content.promoSubtitle)
        personalizedText = personalizedText.replace(/\{\{promoSubtitle\}\}/g, content.promoSubtitle)
      }
      if (content.promoDescription) {
        personalizedHtml = personalizedHtml.replace(/\{\{promoDescription\}\}/g, content.promoDescription)
        personalizedText = personalizedText.replace(/\{\{promoDescription\}\}/g, content.promoDescription)
      }
      if (content.discountCode) {
        personalizedHtml = personalizedHtml.replace(/\{\{discountCode\}\}/g, content.discountCode)
        personalizedText = personalizedText.replace(/\{\{discountCode\}\}/g, content.discountCode)
      }
      if (content.discountAmount) {
        personalizedHtml = personalizedHtml.replace(/\{\{discountAmount\}\}/g, content.discountAmount)
        personalizedText = personalizedText.replace(/\{\{discountAmount\}\}/g, content.discountAmount)
      }
      if (content.expiryDate) {
        personalizedHtml = personalizedHtml.replace(/\{\{expiryDate\}\}/g, content.expiryDate)
        personalizedText = personalizedText.replace(/\{\{expiryDate\}\}/g, content.expiryDate)
      }
      if (content.ctaUrl) {
        personalizedHtml = personalizedHtml.replace(/\{\{ctaUrl\}\}/g, content.ctaUrl)
        personalizedText = personalizedText.replace(/\{\{ctaUrl\}\}/g, content.ctaUrl)
      }
      if (content.ctaText) {
        personalizedHtml = personalizedHtml.replace(/\{\{ctaText\}\}/g, content.ctaText)
        personalizedText = personalizedText.replace(/\{\{ctaText\}\}/g, content.ctaText)
      }

      // Add tracking pixels and links
      const trackingPixel = `<img src="${process.env.NEXT_PUBLIC_APP_URL}/api/marketing/track/open?campaignId=${campaignId}&email=${encodeURIComponent(recipient.email)}" width="1" height="1" style="display:none;" />`
      personalizedHtml += trackingPixel

      const mailOptions = {
        from: process.env.DEFAULT_FROM_EMAIL || "noreply@kilosuperapp.com",
        to: recipient.email,
        subject: content.subject,
        html: personalizedHtml,
        text: personalizedText,
        headers: {
          "X-Campaign-ID": campaignId,
          "X-Recipient-ID": recipient.userId || recipient.email,
        },
      }

      const result = await transporter.sendMail(mailOptions)
      results.sent++
      results.delivered++

      // Log email sent for tracking
      console.log(`Campaign email sent: ${campaignId} -> ${recipient.email}`)
    } catch (error) {
      results.failed++
      results.errors.push({
        email: recipient.email,
        error: error instanceof Error ? error.message : "Unknown error",
      })
      console.error(`Failed to send campaign email to ${recipient.email}:`, error)
    }
  }

  return results
}

// Email templates
export const emailTemplates = {
  welcome: {
    subject: "Welcome to Kilo Super App!",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #333;">Welcome {{name}}!</h1>
        <p>Thank you for joining Kilo Super App. We're excited to have you on board!</p>
        <p>You can now access all our services:</p>
        <ul>
          <li>Auto Parts</li>
          <li>Pharmacy</li>
          <li>Food Delivery</li>
          <li>Grocery</li>
          <li>Ride Booking</li>
        </ul>
        <a href="{{appUrl}}" style="background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block; margin: 20px 0;">
          Get Started
        </a>
        <p>Best regards,<br>The Kilo Super App Team</p>
      </div>
    `,
    text: "Welcome {{name}}! Thank you for joining Kilo Super App. Visit {{appUrl}} to get started.",
  },

  orderConfirmation: {
    subject: "Order Confirmation - #{{orderNumber}}",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #333;">Order Confirmed!</h1>
        <p>Hi {{name}},</p>
        <p>Your order #{{orderNumber}} has been confirmed and is being prepared.</p>
        <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3>Order Details:</h3>
          <p><strong>Order Number:</strong> {{orderNumber}}</p>
          <p><strong>Total:</strong> ${{ total }}</p> <!-- Use the declared total variable -->
          <p><strong>Delivery Address:</strong> {{address}}</p>
          <p><strong>Estimated Delivery:</strong> {{estimatedDelivery}}</p>
        </div>
        <p>You can track your order in the app.</p>
        <p>Thank you for choosing Kilo Super App!</p>
      </div>
    `,
    text: "Order #{{orderNumber}} confirmed! Total: ${{total}}. Track your order in the app.", // Use the declared total variable
  },

  passwordReset: {
    subject: "Reset Your Password",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #333;">Reset Your Password</h1>
        <p>Hi {{name}},</p>
        <p>You requested to reset your password. Click the button below to create a new password:</p>
        <a href="{{resetUrl}}" style="background: #dc3545; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block; margin: 20px 0;">
          Reset Password
        </a>
        <p>This link will expire in 1 hour.</p>
        <p>If you didn't request this, please ignore this email.</p>
        <p>Best regards,<br>The Kilo Super App Team</p>
      </div>
    `,
    text: "Reset your password: {{resetUrl}} (expires in 1 hour)",
  },

  promotional: {
    subject: "{{promoTitle}} - Special Offer Inside!",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px 20px; text-align: center; border-radius: 8px 8px 0 0;">
          <h1 style="margin: 0; font-size: 28px;">{{promoTitle}}</h1>
          <p style="margin: 10px 0 0 0; font-size: 18px;">{{promoSubtitle}}</p>
        </div>
        <div style="padding: 30px 20px; background: white;">
          <p>Hi {{name}},</p>
          <p>{{promoDescription}}</p>
          <div style="text-align: center; margin: 30px 0;">
            <div style="background: #fff3cd; border: 2px dashed #ffc107; padding: 20px; border-radius: 8px; display: inline-block;">
              <h2 style="margin: 0; color: #856404;">{{discountCode}}</h2>
              <p style="margin: 5px 0 0 0; color: #856404;">Use this code for {{discountAmount}} off</p>
            </div>
          </div>
          <div style="text-align: center;">
            <a href="{{ctaUrl}}" style="background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold;">
              {{ctaText}}
            </a>
          </div>
          <p style="margin-top: 30px; font-size: 14px; color: #666;">
            Offer valid until {{expiryDate}}. Terms and conditions apply.
          </p>
        </div>
      </div>
    `,
    text: "{{promoTitle}} - Use code {{discountCode}} for {{discountAmount}} off. Valid until {{expiryDate}}. {{ctaUrl}}",
  },
}

// Function to simulate tracking email opens (for demonstration)
export async function trackEmailOpen(messageId: string) {
  try {
    await prisma.emailLog.updateMany({
      where: { messageId },
      data: { status: "OPENED", openedAt: new Date() },
    })
    console.log(`Email ${messageId} marked as opened.`)
  } catch (error) {
    console.error("Error tracking email open:", error)
  }
}

// Function to simulate tracking email clicks (for demonstration)
export async function trackEmailClick(messageId: string, linkUrl: string) {
  try {
    await prisma.emailLog.updateMany({
      where: { messageId },
      data: { status: "CLICKED", clickedAt: new Date(), clickedLink: linkUrl },
    })
    console.log(`Email ${messageId} marked as clicked on ${linkUrl}.`)
  } catch (error) {
    console.error("Error tracking email click:", error)
  }
}
