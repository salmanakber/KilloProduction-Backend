import twilio from "twilio"

const accountSid = process.env.TWILIO_ACCOUNT_SID
const authToken = process.env.TWILIO_AUTH_TOKEN
const client = twilio(accountSid, authToken)

export async function sendOTP(phone: string, otp: string) {
  try {
    if (!accountSid || !authToken || !process.env.TWILIO_PHONE_NUMBER) {
      throw new Error("Twilio credentials not found")
    }
    if(process.env.SENDING_SMS === "false") return false
    await client.messages.create({
      body: `Your Kilo Super App verification code is: ${otp}. Valid for 10 minutes.`,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: phone,
    })
    return true
  } catch (error) {
    console.error("SMS sending failed:", error)
    return false
  }
}

export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString()
}
