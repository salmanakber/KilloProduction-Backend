import { jwtVerify, SignJWT } from "jose"
import bcrypt from "bcryptjs"
import { cookies } from "next/headers"
import { prisma } from "./prisma"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"
const getSecretKey = () => new TextEncoder().encode(JWT_SECRET)

export interface JWTPayload {
  userId: string
  role: string
  modules?: string[]
}

// ─── Password Hashing ─────────────────────────────────────────────────────────

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12)
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword)
}

// ─── JWT Creation ─────────────────────────────────────────────────────────────

export async function generateToken(payload: JWTPayload): Promise<string> {
  return await new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(getSecretKey())
}

// ─── JWT Verification ─────────────────────────────────────────────────────────

export async function verifyToken(token: string): Promise<JWTPayload | null> {
  try {
    const { payload } = await jwtVerify(token, getSecretKey())
    return payload as JWTPayload
  } catch (err) {
    console.error("Invalid JWT:", err)
    return null
  }
}

// ─── Authenticate From Cookie ─────────────────────────────────────────────────

export async function authenticateRequest() {
  const cookieStore = cookies()
  const token = cookieStore.get("admin-token")?.value

  if (!token) return null

  const payload = await verifyToken(token)
  if (!payload) return null

  const user = await prisma.user.findUnique({
    where: { id: payload.userId },
    include: {
      userProfile: true,
      userSettings: true,
      wallet: true,
    },
  })

  return user
}

// ─── Role-Based Guard ─────────────────────────────────────────────────────────

export function requireAuth(roles?: string[]) {
  return async () => {
    const user = await authenticateRequest()

    if (!user) {
      return new Response("Unauthorized", { status: 401 })
    }

    if (roles && !roles.includes(user.role)) {
      return new Response("Forbidden", { status: 403 })
    }

    return user
  }
}
