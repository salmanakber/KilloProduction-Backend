"use client"

import { Button } from "@/components/ui/button"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Users,
  ShoppingCart,
  DollarSign,
  Truck,
  Settings,
  MessageSquare,
  BarChart,
  Shield,
  Briefcase,
  Bell,
  FileText,
  StoreIcon as BuildingStorefront,
  Car,
  Pill,
  Utensils,
  ShoppingBag,
  Handshake,
} from "lucide-react"

export function AdminSidebar() {
  const pathname = usePathname()

  const navItems = [
    {
      name: "Dashboard",
      href: "/admin",
      icon: LayoutDashboard,
    },
    {
      name: "User Management",
      href: "/admin/users",
      icon: Users,
    },
    {
      name: "Order Management",
      href: "/admin/orders",
      icon: ShoppingCart,
    },
    {
      name: "Payment & Finance",
      href: "/admin/payments",
      icon: DollarSign,
    },
    {
      name: "Rider Management",
      href: "/admin/modules/rider",
      icon: Truck,
    },
    {
      name: "Vendor Management",
      href: "/admin/modules/vendor", // This will be a parent for sub-modules
      icon: BuildingStorefront,
      subItems: [
        { name: "Auto Parts", href: "/admin/modules/auto-parts", icon: Car },
        { name: "Pharmacy", href: "/admin/modules/pharmacy", icon: Pill },
        { name: "Food", href: "/admin/modules/food", icon: Utensils },
        { name: "Grocery", href: "/admin/modules/grocery", icon: ShoppingBag },
      ],
    },
    {
      name: "Wholesaler Management",
      href: "/admin/wholesalers",
      icon: Handshake,
    },
    {
      name: "HR Management",
      href: "/admin/hr",
      icon: Briefcase,
    },
    {
      name: "Marketing Intelligence",
      href: "/admin/marketing",
      icon: BarChart,
    },
    {
      name: "Notifications",
      href: "/admin/notifications",
      icon: Bell,
    },
    {
      name: "Complaints & Support",
      href: "/admin/complaints",
      icon: MessageSquare,
    },
    {
      name: "Reports & Analytics",
      href: "/admin/reports",
      icon: FileText,
    },
    {
      name: "Security & Audit",
      href: "/admin/security",
      icon: Shield,
    },
    {
      name: "Settings",
      href: "/admin/settings",
      icon: Settings,
    },
  ]

  return (
    <aside className="w-64 bg-gray-800 text-white h-full flex flex-col">
      <div className="p-4 border-b border-gray-700">
        <h2 className="text-2xl font-bold text-green-400">Kilo Admin</h2>
      </div>
      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.name}>
              {item.subItems ? (
                <>
                  <div
                    className={cn(
                      "flex items-center px-4 py-2 text-sm font-medium rounded-md cursor-pointer",
                      pathname.startsWith(item.href)
                        ? "bg-gray-700 text-green-400"
                        : "text-gray-300 hover:bg-gray-700 hover:text-white",
                    )}
                  >
                    <item.icon className="h-5 w-5 mr-3" />
                    {item.name}
                  </div>
                  <ul className="ml-8 mt-1 space-y-1">
                    {item.subItems.map((subItem) => (
                      <li key={subItem.name}>
                        <Link
                          href={subItem.href}
                          className={cn(
                            "flex items-center px-4 py-2 text-sm rounded-md",
                            pathname === subItem.href
                              ? "bg-gray-700 text-green-400"
                              : "text-gray-400 hover:bg-gray-700 hover:text-white",
                          )}
                        >
                          <subItem.icon className="h-4 w-4 mr-3" />
                          {subItem.name}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </>
              ) : (
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center px-4 py-2 text-sm font-medium rounded-md",
                    pathname === item.href
                      ? "bg-gray-700 text-green-400"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white",
                  )}
                >
                  <item.icon className="h-5 w-5 mr-3" />
                  {item.name}
                </Link>
              )}
            </li>
          ))}
        </ul>
      </nav>
      <div className="p-4 border-t border-gray-700">
        <Button variant="ghost" className="w-full justify-start text-gray-300 hover:bg-gray-700 hover:text-white">
          Logout
        </Button>
      </div>
    </aside>
  )
}
