"use client"

import { Label } from "@/components/ui/label"

import { useEffect, useState } from "react"
import {
  CheckCircle,
  XCircle,
  Mail,
  Phone,
  Calendar,
  Star,
  MapPin,
  Car,
  Utensils,
  ShoppingCart,
  Pill,
  Bike,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { User } from "../../../app/type/index"

interface UserViewModalProps {
  userId: string
  onClose: () => void
}

export function UserViewModal({ userId, onClose }: UserViewModalProps) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchUser = async () => {
      try {
        setLoading(true)
        const response = await fetch(`/api/admin/users/${userId}`)
        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "Failed to fetch user details")
        }
        const data = await response.json()
        setUser(data.user)
      } catch (err: any) {
        console.error("Error fetching user details:", err)
        setError(err.message || "Could not load user details.")
      } finally {
        setLoading(false)
      }
    }
    fetchUser()
  }, [userId])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ACTIVE":
        return "bg-green-100 text-green-800"
      case "INACTIVE":
        return "bg-gray-100 text-gray-800"
      case "SUSPENDED":
        return "bg-red-100 text-red-800"
      case "PENDING":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getRoleColor = (role: string) => {
    switch (role) {
      case "CUSTOMER":
        return "bg-blue-100 text-blue-800"
      case "VENDOR":
        return "bg-purple-100 text-purple-800"
      case "RIDER":
        return "bg-green-100 text-green-800"
      case "WHOLESALER":
        return "bg-orange-100 text-orange-800"
      case "ADMIN":
      case "SUPER_ADMIN":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getModuleIcon = (module: string) => {
    switch (module) {
      case "PHARMACY":
        return <Pill className="h-4 w-4 mr-1" />
      case "AUTO_PARTS":
        return <Car className="h-4 w-4 mr-1" />
      case "FOOD":
        return <Utensils className="h-4 w-4 mr-1" />
      case "GROCERY":
        return <ShoppingCart className="h-4 w-4 mr-1" />
      case "RIDING":
        return <Bike className="h-4 w-4 mr-1" />
      default:
        return null
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    )
  }

  if (error) {
    return <div className="text-red-500 text-center py-8">{error}</div>
  }

  if (!user) {
    return <div className="text-center py-8 text-gray-500">User not found.</div>
  }

  return (
    <Tabs defaultValue="profile" className="w-full">
      <TabsList className="grid w-full grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
        <TabsTrigger value="profile">Profile</TabsTrigger>
        {user.role === "VENDOR" && user.module && <TabsTrigger value="vendor-details">Vendor Details</TabsTrigger>}
        {user.role === "RIDER" && <TabsTrigger value="rider-details">Rider Details</TabsTrigger>}
        <TabsTrigger value="orders">Orders</TabsTrigger>
        <TabsTrigger value="activity">Activity</TabsTrigger>
      </TabsList>

      <TabsContent value="profile" className="space-y-4 p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex items-center">
                <Mail className="h-4 w-4 mr-2 text-gray-500" />
                <p className="text-sm text-gray-700">{user.email}</p>
              </div>
              <div className="flex items-center">
                <Phone className="h-4 w-4 mr-2 text-gray-500" />
                <p className="text-sm text-gray-700">{user.phone}</p>
              </div>
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-2 text-gray-500" />
                <p className="text-sm text-gray-700">Joined: {new Date(user.joinedAt).toLocaleDateString()}</p>
              </div>
              <div className="flex items-center">
                <MapPin className="h-4 w-4 mr-2 text-gray-500" />
                <p className="text-sm text-gray-700">{user.location || "N/A"}</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Status & Role</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <Label className="text-sm font-medium">Role</Label>
                <Badge className={`mt-1 ${getRoleColor(user.role)}`}>{user.role}</Badge>
              </div>
              {user.module && (
                <div>
                  <Label className="text-sm font-medium">Module</Label>
                  <div className="flex items-center text-sm text-gray-700 mt-1">
                    {getModuleIcon(user.module)}
                    {user.module.replace("_", " ")}
                  </div>
                </div>
              )}
              <div>
                <Label className="text-sm font-medium">Account Status</Label>
                <Badge className={`mt-1 ${getStatusColor(user.status)}`}>{user.status}</Badge>
              </div>
              <div className="flex items-center text-sm text-gray-700">
                {user.isVerified ? (
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-500 mr-2" />
                )}
                {user.isVerified ? "Verified" : "Unverified"}
              </div>
            </CardContent>
          </Card>
        </div>

        {user.userProfile && (
          <Card>
            <CardHeader>
              <CardTitle>Personal Details</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium">Address</Label>
                <p className="text-sm text-gray-700">{user.userProfile.address || "N/A"}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">City</Label>
                <p className="text-sm text-gray-700">{user.userProfile.city || "N/A"}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">State</Label>
                <p className="text-sm text-gray-700">{user.userProfile.state || "N/A"}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Zip Code</Label>
                <p className="text-sm text-gray-700">{user.userProfile.zipCode || "N/A"}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Date of Birth</Label>
                <p className="text-sm text-gray-700">
                  {user.userProfile.dateOfBirth ? new Date(user.userProfile.dateOfBirth).toLocaleDateString() : "N/A"}
                </p>
              </div>
              <div>
                <Label className="text-sm font-medium">Gender</Label>
                <p className="text-sm text-gray-700">{user.userProfile.gender || "N/A"}</p>
              </div>
            </CardContent>
          </Card>
        )}
      </TabsContent>

      {user.role === "VENDOR" && user.module && (
        <TabsContent value="vendor-details" className="space-y-4 p-4">
          {user.module === "PHARMACY" && user.pharmacy && (
            <Card>
              <CardHeader>
                <CardTitle>Pharmacy Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div>
                  <Label className="text-sm font-medium">Pharmacy Name</Label>
                  <p className="text-sm text-gray-700">{user.pharmacy.name}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">License Number</Label>
                  <p className="text-sm text-gray-700">{user.pharmacy.licenseNumber}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Address</Label>
                  <p className="text-sm text-gray-700">{user.pharmacy.address}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Specializations</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {user.pharmacy.specializations.map((spec) => (
                      <Badge key={spec} variant="secondary">
                        {spec}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium">Medicine Origins</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {user.pharmacy.medicineOrigins.map((origin) => (
                      <Badge key={origin} variant="secondary">
                        {origin}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium">Verification Status</Label>
                  <div className="flex items-center text-sm text-gray-700 mt-1">
                    {user.pharmacy.isVerified ? (
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-500 mr-2" />
                    )}
                    {user.pharmacy.isVerified ? "Verified" : "Unverified"}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {user.module === "AUTO_PARTS" && user.autoPartsStore && (
            <Card>
              <CardHeader>
                <CardTitle>Auto Parts Store Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div>
                  <Label className="text-sm font-medium">Business Name</Label>
                  <p className="text-sm text-gray-700">{user.autoPartsStore.businessName}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Business Type</Label>
                  <p className="text-sm text-gray-700">{user.autoPartsStore.businessType}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Registration Number</Label>
                  <p className="text-sm text-gray-700">{user.autoPartsStore.registrationNumber}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Address</Label>
                  <p className="text-sm text-gray-700">{user.autoPartsStore.address}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Specializations</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {user.autoPartsStore.specializations.map((spec) => (
                      <Badge key={spec} variant="secondary">
                        {spec}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium">Brands Carried</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {user.autoPartsStore.brandsCarried.map((brand) => (
                      <Badge key={brand} variant="secondary">
                        {brand}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium">Verification Status</Label>
                  <div className="flex items-center text-sm text-gray-700 mt-1">
                    {user.autoPartsStore.isVerified ? (
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-500 mr-2" />
                    )}
                    {user.autoPartsStore.isVerified ? "Verified" : "Unverified"}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {user.module === "FOOD" && user.restaurant && (
            <Card>
              <CardHeader>
                <CardTitle>Restaurant Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div>
                  <Label className="text-sm font-medium">Restaurant Name</Label>
                  <p className="text-sm text-gray-700">{user.restaurant.name}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Cuisine</Label>
                  <p className="text-sm text-gray-700">{user.restaurant.cuisine}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Address</Label>
                  <p className="text-sm text-gray-700">{user.restaurant.address}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Verification Status</Label>
                  <div className="flex items-center text-sm text-gray-700 mt-1">
                    {user.restaurant.isVerified ? (
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-500 mr-2" />
                    )}
                    {user.restaurant.isVerified ? "Verified" : "Unverified"}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {user.module === "GROCERY" && user.groceryStore && (
            <Card>
              <CardHeader>
                <CardTitle>Grocery Store Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div>
                  <Label className="text-sm font-medium">Store Name</Label>
                  <p className="text-sm text-gray-700">{user.groceryStore.name}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Address</Label>
                  <p className="text-sm text-gray-700">{user.groceryStore.address}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium">Verification Status</Label>
                  <div className="flex items-center text-sm text-gray-700 mt-1">
                    {user.groceryStore.isVerified ? (
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    ) : (
                      <XCircle className="h-4 w-4 text-red-500 mr-2" />
                    )}
                    {user.groceryStore.isVerified ? "Verified" : "Unverified"}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      )}

      {user.role === "RIDER" && user.riderProfile && (
        <TabsContent value="rider-details" className="space-y-4 p-4">
          <Card>
            <CardHeader>
              <CardTitle>Rider Profile</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <Label className="text-sm font-medium">Vehicle Type</Label>
                <p className="text-sm text-gray-700">{user.riderProfile.vehicleType}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">License Number</Label>
                <p className="text-sm text-gray-700">{user.riderProfile.licenseNumber}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Approval Status</Label>
                <div className="flex items-center text-sm text-gray-700 mt-1">
                  {user.riderProfile.isApproved ? (
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-500 mr-2" />
                  )}
                  {user.riderProfile.isApproved ? "Approved" : "Pending/Rejected"}
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium">Verification Status</Label>
                <div className="flex items-center text-sm text-gray-700 mt-1">
                  {user.riderProfile.isVerified ? (
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-500 mr-2" />
                  )}
                  {user.riderProfile.isVerified ? "Verified" : "Unverified"}
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium">Total Rides</Label>
                <p className="text-sm text-gray-700">{user.riderProfile.totalRides}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Total Earnings</Label>
                <p className="text-sm text-gray-700">₦{user.riderProfile.totalEarnings.toLocaleString()}</p>
              </div>
              <div>
                <Label className="text-sm font-medium">Rating</Label>
                <div className="flex items-center text-sm text-gray-700 mt-1">
                  <Star className="h-4 w-4 text-yellow-400 mr-1" />
                  {user.riderProfile.rating.toFixed(1)}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      )}

      <TabsContent value="orders" className="space-y-4 p-4">
        <Card>
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
          </CardHeader>
          <CardContent>
            {(user.customerOrders && user.customerOrders.length > 0) ||
            (user.vendorOrders && user.vendorOrders.length > 0) ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Order ID
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Module
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Amount
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {user.customerOrders?.map((order) => (
                      <tr key={order.id}>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900">
                          {order.id.substring(0, 8)}...
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">{order.module}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900">
                          ₦{order.totalAmount.toLocaleString()}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap">
                          <Badge variant="secondary">{order.status}</Badge>
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                    {user.vendorOrders?.map((order) => (
                      <tr key={order.id}>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900">
                          {order.id.substring(0, 8)}...
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">{order.module} (Vendor)</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900">
                          ₦{order.totalAmount.toLocaleString()}
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap">
                          <Badge variant="secondary">{order.status}</Badge>
                        </td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-center text-gray-500 py-4">No recent orders found.</p>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="activity" className="space-y-4 p-4">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity Log</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500">Activity log coming soon...</p>
            {/* In a real application, you would fetch and display user-specific activity logs here */}
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  )
}
